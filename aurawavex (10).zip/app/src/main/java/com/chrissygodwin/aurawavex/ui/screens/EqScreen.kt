package com.chrissygodwin.aurawavex.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Publish
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.dsp.eq.EqBand
import com.chrissygodwin.aurawavex.dsp.eq.EqBandData
import com.chrissygodwin.aurawavex.dsp.eq.EqualizerPreset
import com.chrissygodwin.aurawavex.dsp.eq.EqualizerPresetManager
import com.chrissygodwin.aurawavex.ui.components.HoloCard
import com.chrissygodwin.aurawavex.ui.theme.CardBackground
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel

@Composable
fun EqScreen(
    viewModel: AudioViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val scrollState = rememberScrollState()
    val uiState by viewModel.uiState.collectAsState()

    // Dialog state for Save, Import, Export Presets
    var showSavePresetDialog by remember { mutableStateOf(false) }
    var showImportPresetDialog by remember { mutableStateOf(false) }
    var showExportPresetDialog by remember { mutableStateOf(false) }
    
    var presetNameInput by remember { mutableStateOf("") }
    var importJsonInput by remember { mutableStateOf("") }
    var exportedJsonText by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header with Power Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "HoloCore™ EQ",
                    style = MaterialTheme.typography.displayMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color = TextPrimary
                )
                Text(
                    text = "64-BIT PARALLEL MULTI-STAGE EQUALIZER",
                    style = MaterialTheme.typography.labelMedium,
                    color = NeonLimeGreen
                )
            }

            // Global EQ Power button
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (uiState.eqEnabled) Color(0xFF1C2C1E) else Color(0xFF1C1C1E))
                    .border(1.dp, if (uiState.eqEnabled) NeonLimeGreen else Color(0xFF2C2C2E), RoundedCornerShape(12.dp))
                    .clickable { viewModel.setEqEnabled(!uiState.eqEnabled) }
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = "Power",
                    tint = if (uiState.eqEnabled) NeonLimeGreen else TextSecondary
                )
                Text(
                    text = if (uiState.eqEnabled) "ENABLED" else "BYPASSED",
                    color = if (uiState.eqEnabled) NeonLimeGreen else TextSecondary,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // EQ Type Selector Tabs (10-Band, 31-Band, Parametric)
        HoloCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "SELECT EQUALIZER ENGINE",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(
                        "10band" to "10-Band Studio",
                        "31band" to "31-Band Master",
                        "parametric" to "Parametric EQ"
                    ).forEach { (typeKey, label) ->
                        val isSelected = uiState.eqType == typeKey
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonLimeGreen else DarkGraphite)
                                .clickable { viewModel.setEqType(typeKey) }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                color = if (isSelected) Color.Black else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }

        // Equalizer Preset Bar
        HoloCard {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "TARGET ACOUSTIC PRESETS",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(uiState.eqPresets) { index, preset ->
                        val isSelected = uiState.selectedEqPresetIndex == index
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) CardBackground else DarkGraphite)
                                .border(1.dp, if (isSelected) NeonLimeGreen else Color(0xFF2C2C2E), RoundedCornerShape(8.dp))
                                .clickable { viewModel.applyEqPreset(index) }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(
                                text = preset,
                                color = if (isSelected) NeonLimeGreen else TextPrimary,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Active EQ Editor Section
        HoloCard {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when (uiState.eqType) {
                            "10band" -> "10-BAND REAL-TIME COEFFS (dB)"
                            "31band" -> "31-BAND 1/3-OCTAVE COEFFS (dB)"
                            else -> "5-BAND FULL PARAMETRIC STAGES"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "+12 dB / -12 dB Gain",
                        style = MaterialTheme.typography.labelMedium,
                        color = RoyalBlue,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Render based on active EQ type
                when (uiState.eqType) {
                    "10band", "31band" -> {
                        // Slider Strip (Horizontal Scroll for 31-band and 10-band)
                        LazyRow(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            itemsIndexed(uiState.eqBands) { index, band ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxHeight()
                                        .width(55.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Band gain display
                                    Text(
                                        text = String.format("%+.1f dB", band.gainDb),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = if (band.gainDb != 0f) NeonLimeGreen else TextSecondary,
                                        textAlign = TextAlign.Center
                                    )

                                    // Vertical Slider Simulation block
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .width(10.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(Color(0xFF151517))
                                            .clickable {
                                                // Quick tap cycle increment
                                                val next = if (band.gainDb >= 12f) -12f else band.gainDb + 2f
                                                viewModel.updateEqBandGain(index, next)
                                            },
                                        contentAlignment = Alignment.BottomCenter
                                    ) {
                                        val normalizedVal = (band.gainDb + 12f) / 24f
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .fillMaxHeight(normalizedVal.coerceIn(0.01f, 1f))
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(
                                                    Brush.verticalGradient(listOf(NeonLimeGreen, RoyalBlue))
                                                )
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    // True Android slider for horizontal dragging support
                                    Slider(
                                        value = band.gainDb,
                                        onValueChange = { viewModel.updateEqBandGain(index, it) },
                                        valueRange = -12f..12f,
                                        colors = SliderDefaults.colors(
                                            thumbColor = NeonLimeGreen,
                                            activeTrackColor = NeonLimeGreen,
                                            inactiveTrackColor = Color.Transparent
                                        ),
                                        modifier = Modifier.height(20.dp)
                                    )

                                    // Frequency Label
                                    Text(
                                        text = formatFreq(band.frequency),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontSize = 9.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                    "parametric" -> {
                        // Parametric stages with Frequency, Gain and Q-Factor adjustable
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            uiState.eqBands.forEachIndexed { index, band ->
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF1C1C1E))
                                        .border(0.5.dp, Color(0xFF2C2C2E), RoundedCornerShape(12.dp))
                                        .padding(12.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Stage ${index + 1} Filter",
                                            fontWeight = FontWeight.Bold,
                                            color = NeonLimeGreen,
                                            style = MaterialTheme.typography.bodyMedium
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Text(
                                                text = "F = ${formatFreq(band.frequency)}",
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                color = TextPrimary
                                            )
                                            Text(
                                                text = "Q = ${String.format("%.2f", band.qFactor)}",
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                color = RoyalBlue
                                            )
                                            Text(
                                                text = "Gain = ${String.format("%+.1f dB", band.gainDb)}",
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                color = if (band.gainDb != 0f) NeonLimeGreen else TextSecondary
                                            )
                                        }
                                    }

                                    // Adjust Frequency Slider
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Freq", color = TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(36.dp))
                                        Slider(
                                            value = band.frequency,
                                            onValueChange = { viewModel.updateEqBandFrequency(index, it) },
                                            valueRange = 20f..20000f,
                                            colors = SliderDefaults.colors(thumbColor = NeonLimeGreen, activeTrackColor = NeonLimeGreen),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    // Adjust Gain Slider
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Gain", color = TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(36.dp))
                                        Slider(
                                            value = band.gainDb,
                                            onValueChange = { viewModel.updateEqBandGain(index, it) },
                                            valueRange = -12f..12f,
                                            colors = SliderDefaults.colors(thumbColor = NeonLimeGreen, activeTrackColor = NeonLimeGreen),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }

                                    // Adjust Q-Factor Slider
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("Q", color = TextSecondary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.width(36.dp))
                                        Slider(
                                            value = band.qFactor,
                                            onValueChange = { viewModel.updateEqBandQFactor(index, it) },
                                            valueRange = 0.1f..10.0f,
                                            colors = SliderDefaults.colors(thumbColor = RoyalBlue, activeTrackColor = RoyalBlue),
                                            modifier = Modifier.weight(1f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Preset Tools & Import/Export Operations
        HoloCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "STUDIO PRESET PROFILE ACTIONS",
                    style = MaterialTheme.typography.labelMedium,
                    color = TextSecondary,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Reset Active EQ
                    Button(
                        onClick = { viewModel.resetEq() },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                        Text("Reset", color = Color.White)
                    }

                    // Save Preset File
                    Button(
                        onClick = { showSavePresetDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                        Text("Save", color = Color.White)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Export Preset
                    Button(
                        onClick = {
                            val preset = EqualizerPreset(
                                name = "Active EQ Setup",
                                isEnabled = uiState.eqEnabled,
                                type = uiState.eqType,
                                bandsData = uiState.eqBands.map { EqBandData(it.id, it.frequency, it.gainDb, it.qFactor, it.isEnabled) }
                            )
                            exportedJsonText = EqualizerPresetManager.exportPresetToJson(preset)
                            showExportPresetDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Publish, contentDescription = "Export", tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                        Text("Export", color = Color.White)
                    }

                    // Import Preset
                    Button(
                        onClick = { showImportPresetDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Import", tint = Color.White)
                        Spacer(Modifier.width(4.dp))
                        Text("Import", color = Color.White)
                    }
                }
            }
        }
    }

    // --- Save Preset dialog ---
    if (showSavePresetDialog) {
        AlertDialog(
            onDismissRequest = { showSavePresetDialog = false },
            title = { Text("Save Equalizer Preset", color = Color.White) },
            text = {
                Column {
                    Text("Enter preset name:", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = presetNameInput,
                        onValueChange = { presetNameInput = it },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonLimeGreen,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        if (presetNameInput.isNotBlank()) {
                            val preset = EqualizerPreset(
                                name = presetNameInput,
                                isEnabled = uiState.eqEnabled,
                                type = uiState.eqType,
                                bandsData = uiState.eqBands.map { EqBandData(it.id, it.frequency, it.gainDb, it.qFactor, it.isEnabled) }
                            )
                            val success = EqualizerPresetManager.savePresetToFile(context, presetNameInput, preset)
                            if (success) {
                                Toast.makeText(context, "Preset saved to files: $presetNameInput", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Failed to write preset file", Toast.LENGTH_SHORT).show()
                            }
                            showSavePresetDialog = false
                            presetNameInput = ""
                        }
                    }
                ) {
                    Text("Save", color = NeonLimeGreen)
                }
            },
            dismissButton = {
                TextButton(onClick = { showSavePresetDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CardBackground
        )
    }

    // --- Import Preset dialog ---
    if (showImportPresetDialog) {
        AlertDialog(
            onDismissRequest = { showImportPresetDialog = false },
            title = { Text("Import Equalizer Preset", color = Color.White) },
            text = {
                Column {
                    Text("Paste JSON preset code below:", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importJsonInput,
                        onValueChange = { importJsonInput = it },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonLimeGreen,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val imported = EqualizerPresetManager.importPresetFromJson(importJsonInput)
                        if (imported != null) {
                            viewModel.setEqType(imported.type)
                            viewModel.setEqEnabled(imported.isEnabled)
                            imported.bandsData.forEach { bandData ->
                                viewModel.updateEqBandGain(bandData.id, bandData.gainDb)
                                viewModel.updateEqBandFrequency(bandData.id, bandData.frequency)
                                viewModel.updateEqBandQFactor(bandData.id, bandData.qFactor)
                            }
                            Toast.makeText(context, "Preset successfully loaded: ${imported.name}", Toast.LENGTH_LONG).show()
                            showImportPresetDialog = false
                            importJsonInput = ""
                        } else {
                            Toast.makeText(context, "Error: Invalid JSON preset structure", Toast.LENGTH_LONG).show()
                        }
                    }
                ) {
                    Text("Load Preset", color = NeonLimeGreen)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportPresetDialog = false }) {
                    Text("Cancel", color = Color.White)
                }
            },
            containerColor = CardBackground
        )
    }

    // --- Export Preset dialog ---
    if (showExportPresetDialog) {
        AlertDialog(
            onDismissRequest = { showExportPresetDialog = false },
            title = { Text("Exported Equalizer Preset JSON", color = Color.White) },
            text = {
                Column {
                    Text("Copy this preset JSON block to share:", color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = exportedJsonText,
                        onValueChange = {},
                        readOnly = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RoyalBlue,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(exportedJsonText))
                            Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = RoyalBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        Spacer(Modifier.width(8.dp))
                        Text("Copy to Clipboard")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showExportPresetDialog = false }) {
                    Text("Dismiss", color = NeonLimeGreen)
                }
            },
            containerColor = CardBackground
        )
    }
}

private fun formatFreq(freq: Float): String {
    return if (freq >= 1000f) {
        String.format("%.1fkHz", freq / 1000f)
    } else {
        String.format("%.0fHz", freq)
    }
}
