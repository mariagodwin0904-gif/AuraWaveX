package com.chrissygodwin.aurawavex.dsp

import java.util.concurrent.atomic.AtomicInteger

/**
 * Manages fine adjustments of ambient spatial effects, decay properties,
 * dynamic transient expansion, and soft-limiter thresholds.
 */
object EffectManager {
    private val roomDecayMs = AtomicInteger(250) // Room delay/reverberation length
    private val phaseCoherenceDeg = AtomicInteger(0) // Phase alignment adjustment (0 - 180 deg)
    
    @Volatile 
    private var transientThreshold = 0.15f // Threshold for dynamic expanders

    fun getRoomDecayMs(): Int = roomDecayMs.get()

    fun setRoomDecayMs(decayMs: Int) {
        roomDecayMs.set(decayMs.coerceIn(50, 1000))
    }

    fun getPhaseCoherence(): Int = phaseCoherenceDeg.get()

    fun setPhaseCoherence(degrees: Int) {
        phaseCoherenceDeg.set(degrees.coerceIn(0, 180))
    }

    fun getTransientThreshold(): Float = transientThreshold

    fun setTransientThreshold(threshold: Float) {
        transientThreshold = threshold.coerceIn(0.01f, 0.9f)
    }

    /**
     * Compute optimized acoustic path metrics for current transducer profiles
     */
    fun calculateAcousticDelay(distanceCm: Float, temperatureCelsius: Float = 20f): Float {
        // Speed of sound in air is approximately 331.4 + 0.6 * temp
        val speedOfSoundMPerS = 331.4f + 0.6f * temperatureCelsius
        val distanceMeters = distanceCm / 100f
        return (distanceMeters / speedOfSoundMPerS) * 1000f // Return delay in milliseconds
    }
}
