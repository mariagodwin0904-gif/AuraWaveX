package com.chrissygodwin.aurawavex.dsp

import com.chrissygodwin.aurawavex.dsp.eq.IProfessionalEqualizer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Centrally coordinates DSP core states, active equalizers, module bypasses,
 * and high-level parameter transitions.
 */
object ProcessingManager {
    private val isBypassed = AtomicBoolean(false)
    val pipeline = AudioProcessingPipeline()
    val executionChain = ProcessingChain()

    fun initialize(sampleRate: Int, channels: Int) {
        pipeline.configure(sampleRate, channels)
        
        // Build initial execution chain based on registered DspCore modules
        syncExecutionChain()
    }

    /**
     * Re-builds the execution sequence from current registered DspCore modules
     */
    fun syncExecutionChain() {
        val modules = DspCore.getAllModules()
        executionChain.setChain(modules)
    }

    fun isBypassed(): Boolean = isBypassed.get()

    fun setBypass(bypass: Boolean) {
        isBypassed.set(bypass)
        DspCore.masterEnabled = !bypass
        pipeline.setPipelineActive(!bypass)
    }

    fun setMasterIntensity(intensity: Float) {
        DspCore.masterIntensity = intensity
    }

    fun getMasterIntensity(): Float = DspCore.masterIntensity

    fun getActiveEqualizer(): IProfessionalEqualizer = DspCore.activeEqualizer

    fun changeEqualizerType(type: String) {
        DspCore.setActiveEqualizerType(type)
    }

    fun resetAll() {
        DspCore.resetAll()
        syncExecutionChain()
    }
}
