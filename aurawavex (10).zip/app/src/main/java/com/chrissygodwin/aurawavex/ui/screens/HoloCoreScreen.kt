package com.chrissygodwin.aurawavex.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.chrissygodwin.aurawavex.ui.components.HoloCard
import com.chrissygodwin.aurawavex.ui.theme.CardBackground
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.ui.theme.TextTertiary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel
import com.chrissygodwin.aurawavex.viewmodel.HoloCoreModule
import kotlin.math.cos
import kotlin.math.sin

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HoloCoreScreen(
    viewModel: AudioViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()
    var showInfoDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- PREMIUM HERO HEADER ---
        HoloCoreHeroHeader()

        // --- SIGNATURE FEATURE HERO CARD ---
        HoloCoreSignatureHeroCard(
            enabled = uiState.holoCoreEnabled,
            intensity = uiState.holoCoreIntensity,
            depth = uiState.holoCoreDepth,
            width = uiState.holoCoreWidth,
            immersion = uiState.holoCoreImmersion,
            naturalness = uiState.holoCoreNaturalness,
            quality = uiState.processingQuality,
            previewActive = uiState.holoCorePreviewActive,
            previewBypass = uiState.previewBypass,
            activePresetName = uiState.profiles[uiState.activeProfileIndex].name,
            sampleRate = uiState.currentTrack.sampleRate,
            bitDepth = uiState.currentTrack.bitDepth,
            activeModulesCount = uiState.modules.count { it.isEnabled && uiState.holoCoreEnabled },
            onToggleEnabled = { viewModel.toggleHoloCore(it) },
            onIntensityChanged = { viewModel.updateHoloCoreIntensity(it) },
            onDepthChanged = { viewModel.updateHoloCoreDepth(it) },
            onWidthChanged = { viewModel.updateHoloCoreWidth(it) },
            onImmersionChanged = { viewModel.updateHoloCoreImmersion(it) },
            onNaturalnessChanged = { viewModel.updateHoloCoreNaturalness(it) },
            onQualityChanged = { viewModel.updateProcessingQuality(it) },
            onTogglePreview = { viewModel.toggleHoloCorePreview(it) },
            onReset = { viewModel.resetHoloCoreSignature() },
            onInfoClick = { showInfoDialog = true }
        )

        // --- MODULAR SECTIONS TITLE ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "INDEPENDENT PROCESSING MODULES",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
                fontWeight = FontWeight.Bold
            )
            if (uiState.holoCoreEnabled) {
                TextButton(
                    onClick = { viewModel.resetAllHoloCoreModules() },
                    colors = ButtonDefaults.textButtonColors(
                        contentColor = NeonLimeGreen
                    ),
                    modifier = Modifier.testTag("reset_all_modules_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset All Modules", style = MaterialTheme.typography.labelMedium)
                }
            }
        }

        // --- 18 INDEPENDENT MODULES CATEGORIZED ---
        val categories = listOf(
            "Acoustic Soundstage & Imaging" to uiState.modules.filter { 
                it.id in listOf("wide_soundstage", "instrument_placement", "stereo_width", "center_imaging", "front_depth", "rear_ambience", "crossfeed", "mid_side") 
            },
            "Transient Retrieval & Focus" to uiState.modules.filter { 
                it.id in listOf("separation", "dynamic", "detail", "vocal") 
            },
            "Frequency Contouring & Refinement" to uiState.modules.filter { 
                it.id in listOf("air", "bass", "treble", "phase") 
            },
            "Signal Ceiling & Safety" to uiState.modules.filter { 
                it.id in listOf("limiter", "anti_clipping") 
            }
        )

        categories.forEach { (catName, catModules) ->
            if (catModules.isNotEmpty()) {
                Text(
                    text = catName.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = NeonLimeGreen.copy(alpha = 0.8f),
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )

                catModules.forEach { module ->
                    ModuleCard(
                        module = module,
                        holoCoreEnabled = uiState.holoCoreEnabled,
                        onModuleToggled = { enabled ->
                            viewModel.updateHoloCoreModule(module.id, enabled, module.strength)
                        },
                        onStrengthChanged = { strength ->
                            viewModel.updateHoloCoreModule(module.id, module.isEnabled, strength)
                        },
                        onReset = {
                            viewModel.resetHoloCoreModule(module.id)
                        }
                    )
                }
            }
        }

        // --- OUTPUT TARGET ROUTING ---
        Text(
            text = "OUTPUT TARGET ROUTING",
            style = MaterialTheme.typography.labelMedium,
            color = TextSecondary,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 16.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = DarkGraphite),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Acoustic Target Path",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "Compensates for transducer acoustic impedance differences.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                val outputRoutes = listOf(
                    Triple("Wired Headphones", "Direct high-current analog stage out", true),
                    Triple("USB DAC Playback", "Hi-Res asynchronous digital stream", true),
                    Triple("Bluetooth Audio", "Wireless SBC/AAC/LDAC transmitter target", true),
                    Triple("Internal Speakers", "Integrated micro-acoustic field stage", true)
                )
                
                outputRoutes.forEachIndexed { routeIndex, route ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (routeIndex == 1) CardBackground else Color.Transparent)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (routeIndex == 1) NeonLimeGreen else TextTertiary)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = route.first,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = if (routeIndex == 1) NeonLimeGreen else TextPrimary
                                )
                                Text(
                                    text = route.second,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                        }
                        if (routeIndex == 1) {
                            Text(
                                text = "ACTIVE",
                                style = MaterialTheme.typography.labelSmall,
                                color = NeonLimeGreen,
                                fontWeight = FontWeight.ExtraBold
                            )
                        } else {
                            Text(
                                text = "READY",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextTertiary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    if (routeIndex < outputRoutes.size - 1) {
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                }
            }
        }
    }

    // --- DIALOG DETAIL MODAL ---
    if (showInfoDialog) {
        Dialog(onDismissRequest = { showInfoDialog = false }) {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(24.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonLimeGreen.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = NeonLimeGreen,
                        modifier = Modifier.size(48.dp)
                    )
                    
                    Text(
                        text = "HoloCore™ 3D Technology",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = "HoloCore™ simulates a true high-fidelity loudspeaker soundstage inside your headphones. Utilizing advanced head-related transfer functions (HRTF) and 64-bit real-time phase alignment, it eliminates the congested 'in-your-head' acoustic fatigue characteristic of typical stereo streams.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Text(
                        text = "For optimal experience, use reference over-ear headphones and bypass secondary software equalizer apps.",
                        style = MaterialTheme.typography.bodySmall,
                        color = NeonLimeGreen.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center,
                        fontWeight = FontWeight.SemiBold
                    )

                    Button(
                        onClick = { showInfoDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonLimeGreen, contentColor = Color.Black),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Text("Close", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}


@Composable
fun HoloCoreHeroHeader(
    modifier: Modifier = Modifier
) {
    // Waveform phase animations for header
    val infiniteTransition = rememberInfiniteTransition(label = "header_waves")
    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(5000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "header_wave_phase_1"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(130.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0x1A1A1A1A)) // Dark base
            .border(
                width = 1.dp,
                brush = Brush.horizontalGradient(
                    colors = listOf(
                        Color(0xFF3A59D4).copy(alpha = 0.6f), // Royal Blue
                        Color(0xFFCCFF00).copy(alpha = 0.6f)  // Neon Lime
                    )
                ),
                shape = RoundedCornerShape(20.dp)
            )
            .drawBehind {
                // Royal Blue glow from bottom left
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3A59D4).copy(alpha = 0.18f), Color.Transparent),
                        radius = 200.dp.toPx()
                    ),
                    center = androidx.compose.ui.geometry.Offset(0f, size.height)
                )
                // Neon Lime glow from top right
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFFCCFF00).copy(alpha = 0.12f), Color.Transparent),
                        radius = 180.dp.toPx()
                    ),
                    center = androidx.compose.ui.geometry.Offset(size.width, 0f)
                )

                // Animated neural waves
                val width = size.width
                val height = size.height
                val midY = height / 2f
                val path = Path()
                path.moveTo(0f, midY)
                val steps = 80
                val stepX = width / steps
                for (i in 0..steps) {
                    val x = i * stepX
                    val angle = (x / width) * 3f * Math.PI.toFloat() + phase1
                    val y = midY + sin(angle) * 14.dp.toPx()
                    path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    color = Color(0xFF3A59D4).copy(alpha = 0.15f),
                    style = Stroke(width = 3.dp.toPx())
                )
                
                val path2 = Path()
                path2.moveTo(0f, midY)
                for (i in 0..steps) {
                    val x = i * stepX
                    val angle = (x / width) * 4f * Math.PI.toFloat() - phase1
                    val y = midY + cos(angle) * 8.dp.toPx()
                    path2.lineTo(x, y)
                }
                drawPath(
                    path = path2,
                    color = Color(0xFFCCFF00).copy(alpha = 0.15f),
                    style = Stroke(width = 2.dp.toPx())
                )
            }
            .padding(18.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFFCCFF00).copy(alpha = 0.15f))
                    .padding(horizontal = 6.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "SIGNATURE TECHNOLOGY",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFFCCFF00),
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "HoloCore™",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary,
                letterSpacing = 1.sp
            )
            Text(
                text = "POWERED BY AURAWAVEX",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            )
        }
    }
}


@Composable
fun RealtimeActivityIndicator(active: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(16.dp)) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .scale(if (active) scale else 1.0f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        if (active) Color(0xFFCCFF00).copy(alpha = alpha * 0.4f)
                        else Color(0xFF3A59D4).copy(alpha = 0.3f)
                    )
            )
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (active) Color(0xFFCCFF00) else Color(0xFF3A59D4))
            )
        }
        Text(
            text = if (active) "ENGINE ACTIVE" else "BYPASSED",
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = if (active) Color(0xFFCCFF00) else TextTertiary
        )
    }
}


@Composable
fun InteractiveSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    testTag: String
) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "${(value * 100).toInt()}%",
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = NeonLimeGreen
            )
        }
        Slider(
            value = value,
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor = NeonLimeGreen,
                activeTrackColor = NeonLimeGreen,
                inactiveTrackColor = TextTertiary
            ),
            modifier = Modifier.testTag(testTag)
        )
    }
}


@Composable
fun ProcessingQualitySelector(
    selectedQuality: String,
    onQualitySelected: (String) -> Unit
) {
    val options = listOf("Standard 64-bit", "Oversampled 2x", "Ultra-High 4x")
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(
            text = "DSP Processing Quality",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { option ->
                val isSelected = selectedQuality == option || (selectedQuality == "Ultra Precision (64-bit)" && option == "Standard 64-bit")
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) NeonLimeGreen.copy(alpha = 0.15f) else Color.Transparent)
                        .border(
                            width = 1.dp,
                            color = if (isSelected) NeonLimeGreen else Color(0xFF2C2C2E),
                            shape = RoundedCornerShape(10.dp)
                        )
                        .clickable { onQualitySelected(option) }
                        .padding(vertical = 10.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = option,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) NeonLimeGreen else TextPrimary,
                        maxLines = 1
                    )
                }
            }
        }
    }
}


@Composable
fun HoloCoreSignatureHeroCard(
    enabled: Boolean,
    intensity: Float,
    depth: Float,
    width: Float,
    immersion: Float,
    naturalness: Float,
    quality: String,
    previewActive: Boolean,
    previewBypass: Boolean,
    activePresetName: String,
    sampleRate: String,
    bitDepth: String,
    activeModulesCount: Int,
    onToggleEnabled: (Boolean) -> Unit,
    onIntensityChanged: (Float) -> Unit,
    onDepthChanged: (Float) -> Unit,
    onWidthChanged: (Float) -> Unit,
    onImmersionChanged: (Float) -> Unit,
    onNaturalnessChanged: (Float) -> Unit,
    onQualityChanged: (String) -> Unit,
    onTogglePreview: (Boolean) -> Unit,
    onReset: () -> Unit,
    onInfoClick: () -> Unit
) {
    // Waveform phase animations
    val infiniteTransition = rememberInfiniteTransition(label = "neural_waves")
    val phase1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(4500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase_1"
    )
    val phase2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(6500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase_2"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("holocore_signature_hero_card"),
        colors = CardDefaults.cardColors(
            containerColor = if (enabled) Color(0x2E1A1A1A) else Color(0x1F1A1A1A)
        ),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(
            width = if (enabled) 2.dp else 1.2.dp,
            brush = Brush.radialGradient(
                colors = if (enabled) {
                    listOf(Color(0xFFCCFF00), Color(0xFF3A59D4).copy(alpha = 0.4f))
                } else {
                    listOf(Color(0xFF3A59D4).copy(alpha = 0.8f), Color(0xFF1E1E1E))
                }
            )
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    if (enabled) {
                        val widthVal = size.width
                        val heightVal = size.height
                        val midY = heightVal / 1.7f
                        val path1 = Path()
                        val path2 = Path()

                        path1.moveTo(0f, midY)
                        path2.moveTo(0f, midY)

                        val steps = 100
                        val stepX = widthVal / steps
                        for (i in 0..steps) {
                            val x = i * stepX
                            // Multiple sin/cos combinations for beautiful organic neural wave flow
                            val angle1 = (x / widthVal) * 2f * Math.PI.toFloat() * 1.5f + phase1
                            val y1 = midY + sin(angle1) * (18.dp.toPx() + sin(phase1) * 6.dp.toPx())

                            val angle2 = (x / widthVal) * 2f * Math.PI.toFloat() * 2.5f + phase2
                            val y2 = midY + cos(angle2) * (12.dp.toPx() + cos(phase2) * 4.dp.toPx())

                            path1.lineTo(x, y1)
                            path2.lineTo(x, y2)
                        }

                        // Neon Lime Green Active wave
                        drawPath(
                            path = path1,
                            color = Color(0xFFCCFF00).copy(alpha = 0.28f),
                            style = Stroke(width = 2.5.dp.toPx())
                        )
                        // Royal Blue secondary wave
                        drawPath(
                            path = path2,
                            color = Color(0xFF3A59D4).copy(alpha = 0.22f),
                            style = Stroke(width = 1.8.dp.toPx())
                        )
                    }
                }
                .padding(20.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Header & Badges Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Badge Row
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF3A59D4).copy(alpha = 0.15f))
                                .border(1.dp, Color(0xFF3A59D4), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "★ SIGNATURE FEATURE",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF8FA1EC)
                            )
                        }

                        RealtimeActivityIndicator(active = enabled)
                    }

                    // Info Button
                    IconButton(
                        onClick = onInfoClick,
                        modifier = Modifier
                            .size(32.dp)
                            .testTag("holocore_hero_info_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "HoloCore Info",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // Logo and Master Switch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "HoloCore™ 3D",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Holographic Sound Simulation",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (enabled) Color(0xFFCCFF00) else Color(0xFF3A59D4)
                        )
                    }

                    Switch(
                        checked = enabled,
                        onCheckedChange = onToggleEnabled,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.Black,
                            checkedTrackColor = Color(0xFFCCFF00),
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = TextTertiary
                        ),
                        modifier = Modifier.testTag("holocore_master_switch")
                    )
                }

                // Description Block
                Text(
                    text = "HoloCore™ 3D Holographic Sound Simulation recreates a spacious, immersive headphone listening experience with enhanced soundstage, depth perception, instrument placement and natural spatial presentation.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (enabled) TextPrimary else TextSecondary,
                    lineHeight = 18.sp
                )

                // Realtime Processing Status Display
                if (enabled) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E1E1E).copy(alpha = 0.5f))
                            .padding(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(if (previewActive && previewBypass) Color(0xFF3A59D4) else Color(0xFFCCFF00))
                        )
                        Text(
                            text = if (previewActive) {
                                if (previewBypass) "PROCESSING STATUS: BYPASSED (A/B RUNNING)" else "PROCESSING STATUS: HOLOCORE ACTIVE (A/B RUNNING)"
                            } else {
                                "PROCESSING STATUS: STABLE REALTIME REALTIME PIPELINE ACTIVE"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (previewActive && previewBypass) Color(0xFF3A59D4) else Color(0xFFCCFF00),
                            letterSpacing = 0.5.sp
                        )
                    }
                }

                // Audio Output Status Panel (Grid specs)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFF1E1E1E).copy(alpha = 0.4f))
                        .border(1.dp, Color(0xFF2C2C2E), RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "AUDIO OUTPUT CONFIGURATION",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextTertiary,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "HoloCore Active",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.ExtraBold,
                                color = if (enabled) Color(0xFFCCFF00) else TextTertiary
                            )
                        }
                        
                        Divider(color = Color(0xFF2C2C2E), thickness = 0.5.dp)

                        val simulatedCpuVal = (1.2f + activeModulesCount * 0.45f + intensity * 1.5f)
                        val simulatedCpuStr = "${((simulatedCpuVal * 10).toInt() / 10.0)}%"
                        
                        val simulatedGflopsVal = (0.8f + activeModulesCount * 0.32f + intensity * 0.8f)
                        val simulatedGflopsStr = "${((simulatedGflopsVal * 10).toInt() / 10.0)} GFLOPS"

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("SAMPLE RATE", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                                Text(sampleRate, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("BIT DEPTH", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                                Text(bitDepth, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("PRESET PROFILE", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                                Text(activePresetName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = NeonLimeGreen)
                            }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("DSP CORES LOAD", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                                Text(simulatedCpuStr, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            Column(modifier = Modifier.weight(2f)) {
                                Text("COMPUTATIONAL POWER", style = MaterialTheme.typography.labelSmall, color = TextTertiary)
                                Text(simulatedGflopsStr, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                        }
                    }
                }

                // Intensity and Controls Section
                if (enabled) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        
                        InteractiveSlider(
                            label = "Master Spatial Intensity",
                            value = intensity,
                            onValueChange = onIntensityChanged,
                            testTag = "holocore_hero_intensity_slider"
                        )

                        InteractiveSlider(
                            label = "Soundstage Depth Expansion",
                            value = depth,
                            onValueChange = onDepthChanged,
                            testTag = "holocore_hero_depth_slider"
                        )

                        InteractiveSlider(
                            label = "Stereo Width Field",
                            value = width,
                            onValueChange = onWidthChanged,
                            testTag = "holocore_hero_width_slider"
                        )

                        InteractiveSlider(
                            label = "Acoustic Immersion",
                            value = immersion,
                            onValueChange = onImmersionChanged,
                            testTag = "holocore_hero_immersion_slider"
                        )

                        InteractiveSlider(
                            label = "Acoustic Naturalness Factor",
                            value = naturalness,
                            onValueChange = onNaturalnessChanged,
                            testTag = "holocore_hero_naturalness_slider"
                        )

                        ProcessingQualitySelector(
                            selectedQuality = quality,
                            onQualitySelected = onQualityChanged
                        )

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Preview Toggle
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Switch(
                                    checked = previewActive,
                                    onCheckedChange = onTogglePreview,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.Black,
                                        checkedTrackColor = Color(0xFFCCFF00),
                                        uncheckedThumbColor = TextSecondary,
                                        uncheckedTrackColor = TextTertiary
                                    ),
                                    modifier = Modifier
                                        .scale(0.85f)
                                        .testTag("holocore_hero_preview_toggle")
                                )
                                Text(
                                    text = "Automated A/B Preview",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (previewActive) Color(0xFFCCFF00) else TextSecondary
                                )
                            }

                            // Reset Button
                            TextButton(
                                onClick = onReset,
                                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFF8FA1EC)),
                                modifier = Modifier.testTag("holocore_hero_reset_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Refresh,
                                    contentDescription = "Reset Signature",
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reset Engine", style = MaterialTheme.typography.labelMedium)
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun ModuleCard(
    module: HoloCoreModule,
    holoCoreEnabled: Boolean,
    onModuleToggled: (Boolean) -> Unit,
    onStrengthChanged: (Float) -> Unit,
    onReset: () -> Unit
) {
    val activeGlow = module.isEnabled && holoCoreEnabled
    val animatedBorderColor by animateColorAsState(
        targetValue = if (activeGlow) NeonLimeGreen.copy(alpha = 0.4f) else Color(0xFF2C2C2E),
        animationSpec = tween(durationMillis = 200),
        label = "module_border"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = DarkGraphite),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, animatedBorderColor)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = module.name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (activeGlow) NeonLimeGreen else TextPrimary
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = module.description,
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                Switch(
                    checked = module.isEnabled && holoCoreEnabled,
                    onCheckedChange = onModuleToggled,
                    enabled = holoCoreEnabled,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = NeonLimeGreen,
                        uncheckedThumbColor = TextSecondary,
                        uncheckedTrackColor = TextTertiary
                    ),
                    modifier = Modifier.testTag("switch_${module.id}")
                )
            }

            if (module.isEnabled && holoCoreEnabled) {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Slider(
                        value = module.strength,
                        onValueChange = onStrengthChanged,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("slider_${module.id}"),
                        colors = SliderDefaults.colors(
                            thumbColor = NeonLimeGreen,
                            activeTrackColor = NeonLimeGreen,
                            inactiveTrackColor = TextTertiary
                        )
                    )
                    
                    Spacer(modifier = Modifier.width(12.dp))
                    
                    IconButton(
                        onClick = onReset,
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("reset_${module.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Module",
                            tint = TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Intensity Level",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextTertiary
                    )
                    Text(
                        text = "${(module.strength * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NeonLimeGreen
                    )
                }
            }
        }
    }
}
