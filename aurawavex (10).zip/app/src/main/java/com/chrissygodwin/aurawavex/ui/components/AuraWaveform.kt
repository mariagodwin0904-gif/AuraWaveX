package com.chrissygodwin.aurawavex.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import kotlin.math.sin

@Composable
fun AuraWaveform(
    modifier: Modifier = Modifier,
    isPlaying: Boolean = true,
    intensity: Float = 1.0f
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform_anim")

    // Animators for different phase shifts to make layers look independent and rich
    val phaseShift1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase1"
    )

    val phaseShift2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (-2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase2"
    )

    val phaseShift3 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase3"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(Color.Transparent)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(vertical = 12.dp)
        ) {
            val width = size.width
            val height = size.height
            val centerY = height / 2f

            // Generate paths for three distinct oscillating waves
            val path1 = Path()
            val path2 = Path()
            val path3 = Path()

            path1.moveTo(0f, centerY)
            path2.moveTo(0f, centerY)
            path3.moveTo(0f, centerY)

            val steps = 120
            val dx = width / steps

            for (i in 0..steps) {
                val x = i * dx
                val normalizedX = i.toFloat() / steps

                // Apply a bell-curve envelope so waves pinch elegantly towards the left and right borders (pure high-end oscilloscope look)
                val envelope = sin(normalizedX * Math.PI).toFloat() * intensity

                // Wave 1 - Primary Neon Green (Thick & Energetic)
                val angle1 = (normalizedX * 3.5 * Math.PI) + (if (isPlaying) phaseShift1 else 0f)
                val y1 = centerY + (sin(angle1).toFloat() * 45f * envelope)
                if (i == 0) path1.moveTo(x, y1) else path1.lineTo(x, y1)

                // Wave 2 - Secondary Blue (Slower, atmospheric, deeper)
                val angle2 = (normalizedX * 2.0 * Math.PI) + (if (isPlaying) phaseShift2 else 0f)
                val y2 = centerY + (sin(angle2).toFloat() * 30f * envelope)
                if (i == 0) path2.moveTo(x, y2) else path2.lineTo(x, y2)

                // Wave 3 - High frequency green-blue blend (Faint, rapid)
                val angle3 = (normalizedX * 7.0 * Math.PI) + (if (isPlaying) phaseShift3 else 0f)
                val y3 = centerY + (sin(angle3).toFloat() * 15f * envelope)
                if (i == 0) path3.moveTo(x, y3) else path3.lineTo(x, y3)
            }

            // Draw Background atmospheric grid line (minimalist studio rack design)
            val gridColor = Color(0xFF1C1C1E)
            val gridSpacing = 40f
            for (y in 0..(height / gridSpacing).toInt()) {
                val gridY = y * gridSpacing
                drawLine(
                    color = gridColor,
                    start = Offset(0f, gridY),
                    end = Offset(width, gridY),
                    strokeWidth = 1f
                )
            }
            // Vertical grid lines
            for (x in 0..(width / gridSpacing).toInt()) {
                val gridX = x * gridSpacing
                drawLine(
                    color = gridColor,
                    start = Offset(gridX, 0f),
                    end = Offset(gridX, height),
                    strokeWidth = 1f
                )
            }

            // Central reference line
            drawLine(
                color = Color(0x33CCFF00),
                start = Offset(0f, centerY),
                end = Offset(width, centerY),
                strokeWidth = 1.5f
            )

            // Draw Wave 2 (Royal Blue depth layer)
            drawPath(
                path = path2,
                brush = Brush.horizontalGradient(listOf(RoyalBlue, RoyalBlue.copy(alpha = 0.5f))),
                style = Stroke(width = 3.dp.toPx())
            )

            // Draw Wave 3 (Ambient thin detail)
            drawPath(
                path = path3,
                brush = Brush.horizontalGradient(listOf(Color(0xFF3A59D4), Color(0xFFCCFF00))),
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Draw Wave 1 (Neon Lime Green sharp core)
            drawPath(
                path = path1,
                brush = Brush.horizontalGradient(listOf(NeonLimeGreen, NeonLimeGreen.copy(alpha = 0.7f))),
                style = Stroke(width = 4.dp.toPx())
            )
        }
    }
}
