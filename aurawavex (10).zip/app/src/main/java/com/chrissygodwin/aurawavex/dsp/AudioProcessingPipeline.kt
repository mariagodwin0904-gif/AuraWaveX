package com.chrissygodwin.aurawavex.dsp

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Handles block-based low-latency audio processing for HoloCore™ DSP.
 * Bridges raw byte streams with DspCore floating point calculation.
 */
class AudioProcessingPipeline {
    private val isPipelineActive = AtomicBoolean(true)
    private var sampleRate: Float = 44100f
    private var channelCount: Int = 2
    
    // Output sample buffer
    private var tempBufferL = FloatArray(1024)
    private var tempBufferR = FloatArray(1024)

    fun configure(sampleRate: Int, channelCount: Int) {
        this.sampleRate = sampleRate.toFloat()
        this.channelCount = channelCount
        DspCore.eq10Band.recalculateFilters(this.sampleRate)
        DspCore.eq31Band.recalculateFilters(this.sampleRate)
        DspCore.eqParametric.recalculateFilters(this.sampleRate)
    }

    fun isPipelineActive(): Boolean = isPipelineActive.get()

    fun setPipelineActive(active: Boolean) {
        isPipelineActive.set(active)
    }

    /**
     * Processes standard 16-bit PCM buffer block inside a ByteBuffer in-place
     */
    fun processByteBuffers(inputBuffer: ByteBuffer, outputBuffer: ByteBuffer) {
        if (!isPipelineActive.get() || !DspCore.masterEnabled) {
            outputBuffer.put(inputBuffer)
            return
        }

        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        val shortBuffer = inputBuffer.asShortBuffer()
        val outShortBuffer = outputBuffer.asShortBuffer()
        val samplesCount = shortBuffer.remaining()

        if (channelCount == 2) {
            val pairs = samplesCount / 2
            
            // Adjust temp float array size if needed
            if (tempBufferL.size < pairs) {
                tempBufferL = FloatArray(pairs * 2)
                tempBufferR = FloatArray(pairs * 2)
            }

            for (p in 0 until pairs) {
                if (shortBuffer.remaining() >= 2) {
                    val rawL = shortBuffer.get()
                    val rawR = shortBuffer.get()

                    // Convert to float
                    val floatL = rawL.toFloat() / 32768f
                    val floatR = rawR.toFloat() / 32768f

                    // Run through DspCore processing
                    val (outFloatL, outFloatR) = DspCore.processSample(floatL, floatR, sampleRate)

                    // Convert back to PCM 16-bit safely
                    val pcmL = (outFloatL * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    val pcmR = (outFloatR * 32767f).toInt().coerceIn(-32768, 32767).toShort()

                    outShortBuffer.put(pcmL)
                    outShortBuffer.put(pcmR)
                }
            }
        } else {
            // Mono stream processing
            for (i in 0 until samplesCount) {
                if (shortBuffer.hasRemaining()) {
                    val raw = shortBuffer.get()
                    val floatVal = raw.toFloat() / 32768f
                    val (outFloat, _) = DspCore.processSample(floatVal, floatVal, sampleRate)
                    val pcm = (outFloat * 32767f).toInt().coerceIn(-32768, 32767).toShort()
                    outShortBuffer.put(pcm)
                }
            }
        }

        inputBuffer.position(inputBuffer.limit())
        outputBuffer.limit(remaining)
    }

    /**
     * Floating point array direct rendering (useful for Native openSL/AAudio JNI or float streams)
     */
    fun processFloatArrays(inputL: FloatArray, inputR: FloatArray, outputL: FloatArray, outputR: FloatArray, length: Int) {
        if (!isPipelineActive.get() || !DspCore.masterEnabled) {
            System.arraycopy(inputL, 0, outputL, 0, length)
            System.arraycopy(inputR, 0, outputR, 0, length)
            return
        }

        for (i in 0 until length) {
            val (newL, newR) = DspCore.processSample(inputL[i], inputR[i], sampleRate)
            outputL[i] = newL
            outputR[i] = newR
        }
    }
}
