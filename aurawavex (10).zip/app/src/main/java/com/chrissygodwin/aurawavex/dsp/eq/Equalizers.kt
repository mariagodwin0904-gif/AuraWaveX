package com.chrissygodwin.aurawavex.dsp.eq

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import java.io.File
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin

/**
 * Data representation of an Equalizer Band
 */
data class EqBand(
    val id: Int,
    var frequency: Float, // Center frequency in Hz
    var gainDb: Float,    // Gain in dB (-12.0 to +12.0)
    var qFactor: Float = 1.414f, // Quality factor
    var isEnabled: Boolean = true
) {
    // Biquad filter state for left and right channels
    @Transient var x1L: Float = 0f
    @Transient var x2L: Float = 0f
    @Transient var y1L: Float = 0f
    @Transient var y2L: Float = 0f

    @Transient var x1R: Float = 0f
    @Transient var x2R: Float = 0f
    @Transient var y1R: Float = 0f
    @Transient var y2R: Float = 0f

    // Biquad filter coefficients
    @Transient var b0: Float = 1f
    @Transient var b1: Float = 0f
    @Transient var b2: Float = 0f
    @Transient var a0: Float = 1f
    @Transient var a1: Float = 0f
    @Transient var a2: Float = 0f

    /**
     * Computes the peaking EQ biquad filter coefficients
     * Reference: Robert Bristow-Johnson's Audio EQ Cookbook
     */
    fun recalculateCoefficients(sampleRate: Float) {
        if (!isEnabled || gainDb == 0f) {
            b0 = 1f; b1 = 0f; b2 = 0f; a0 = 1f; a1 = 0f; a2 = 0f
            return
        }

        val w0 = (2f * Math.PI * frequency / sampleRate).toFloat()
        val alpha = (sin(w0.toDouble()) / (2.0 * qFactor)).toFloat()
        val A = 10f.pow(gainDb / 40f)

        val b0d = 1f + alpha * A
        val b1d = -2f * cos(w0)
        val b2d = 1f - alpha * A
        val a0d = 1f + alpha / A
        val a1d = -2f * cos(w0)
        val a2d = 1f - alpha / A

        // Normalize
        b0 = b0d / a0d
        b1 = b1d / a0d
        b2 = b2d / a0d
        a0 = 1f
        a1 = a1d / a0d
        a2 = a2d / a0d
    }

    /**
     * Reset the internal delay buffers to prevent pop/click noise
     */
    fun resetHistory() {
        x1L = 0f; x2L = 0f; y1L = 0f; y2L = 0f
        x1R = 0f; x2R = 0f; y1R = 0f; y2R = 0f
    }

    /**
     * Process a single stereo sample pair through this band's biquad filter
     */
    fun process(inputL: Float, inputR: Float): Pair<Float, Float> {
        if (!isEnabled || gainDb == 0f) return Pair(inputL, inputR)

        // Left Channel
        val outL = b0 * inputL + b1 * x1L + b2 * x2L - a1 * y1L - a2 * y2L
        x2L = x1L
        x1L = inputL
        y2L = y1L
        y1L = outL

        // Right Channel
        val outR = b0 * inputR + b1 * x1R + b2 * x2R - a1 * y1R - a2 * y2R
        x2R = x1R
        x1R = inputR
        y2R = y1R
        y1R = outR

        return Pair(outL, outR)
    }
}

/**
 * Common interface representing professional equalizers
 */
interface IProfessionalEqualizer {
    val name: String
    var isEnabled: Boolean
    val bands: List<EqBand>
    
    fun setGain(bandId: Int, gainDb: Float)
    fun setFrequency(bandId: Int, freq: Float)
    fun setQFactor(bandId: Int, q: Float)
    fun setBandEnabled(bandId: Int, enabled: Boolean)
    fun reset()
    fun recalculateFilters(sampleRate: Float)
    fun processStereo(inputL: Float, inputR: Float): Pair<Float, Float>
}

/**
 * Professional 10-Band Graphic Equalizer
 */
class Professional10BandEqualizer : IProfessionalEqualizer {
    override val name: String = "10-Band Studio Equalizer"
    override var isEnabled: Boolean = true
    
    private val standardFrequencies = listOf(
        31.25f, 62.5f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f
    )

    override val bands: List<EqBand> = standardFrequencies.mapIndexed { idx, freq ->
        EqBand(id = idx, frequency = freq, gainDb = 0f, qFactor = 1.414f)
    }

    override fun setGain(bandId: Int, gainDb: Float) {
        bands.getOrNull(bandId)?.gainDb = gainDb.coerceIn(-12f, 12f)
    }

    override fun setFrequency(bandId: Int, freq: Float) {
        bands.getOrNull(bandId)?.frequency = freq.coerceIn(20f, 22000f)
    }

    override fun setQFactor(bandId: Int, q: Float) {
        bands.getOrNull(bandId)?.qFactor = q.coerceIn(0.1f, 10f)
    }

    override fun setBandEnabled(bandId: Int, enabled: Boolean) {
        bands.getOrNull(bandId)?.isEnabled = enabled
    }

    override fun reset() {
        bands.forEach {
            it.gainDb = 0f
            it.qFactor = 1.414f
            it.isEnabled = true
            it.resetHistory()
        }
    }

    override fun recalculateFilters(sampleRate: Float) {
        bands.forEach { it.recalculateCoefficients(sampleRate) }
    }

    override fun processStereo(inputL: Float, inputR: Float): Pair<Float, Float> {
        if (!isEnabled) return Pair(inputL, inputR)
        var currentL = inputL
        var currentR = inputR
        for (band in bands) {
            val (newL, newR) = band.process(currentL, currentR)
            currentL = newL
            currentR = newR
        }
        return Pair(currentL, currentR)
    }
}

/**
 * Professional 31-Band 1/3-Octave Mastering Equalizer
 */
class Professional31BandEqualizer : IProfessionalEqualizer {
    override val name: String = "31-Band Mastering Equalizer"
    override var isEnabled: Boolean = false

    private val standardFrequencies = listOf(
        20f, 25f, 31.5f, 40f, 50f, 63f, 80f, 100f, 125f, 160f, 200f, 250f, 315f, 400f, 500f, 630f, 800f,
        1000f, 1250f, 1600f, 2000f, 2500f, 3150f, 4000f, 5000f, 6300f, 8000f, 10000f, 12500f, 16000f, 20000f
    )

    override val bands: List<EqBand> = standardFrequencies.mapIndexed { idx, freq ->
        EqBand(id = idx, frequency = freq, gainDb = 0f, qFactor = 4.318f) // Narrower Q for 31-band
    }

    override fun setGain(bandId: Int, gainDb: Float) {
        bands.getOrNull(bandId)?.gainDb = gainDb.coerceIn(-12f, 12f)
    }

    override fun setFrequency(bandId: Int, freq: Float) {
        bands.getOrNull(bandId)?.frequency = freq.coerceIn(10f, 24000f)
    }

    override fun setQFactor(bandId: Int, q: Float) {
        bands.getOrNull(bandId)?.qFactor = q.coerceIn(0.1f, 20f)
    }

    override fun setBandEnabled(bandId: Int, enabled: Boolean) {
        bands.getOrNull(bandId)?.isEnabled = enabled
    }

    override fun reset() {
        bands.forEach {
            it.gainDb = 0f
            it.qFactor = 4.318f
            it.isEnabled = true
            it.resetHistory()
        }
    }

    override fun recalculateFilters(sampleRate: Float) {
        bands.forEach { it.recalculateCoefficients(sampleRate) }
    }

    override fun processStereo(inputL: Float, inputR: Float): Pair<Float, Float> {
        if (!isEnabled) return Pair(inputL, inputR)
        var currentL = inputL
        var currentR = inputR
        for (band in bands) {
            val (newL, newR) = band.process(currentL, currentR)
            currentL = newL
            currentR = newR
        }
        return Pair(currentL, currentR)
    }
}

/**
 * Professional Fully Parametric Equalizer (5 fully customizable bands)
 */
class ProfessionalParametricEqualizer : IProfessionalEqualizer {
    override val name: String = "Fully Parametric Equalizer"
    override var isEnabled: Boolean = false

    override val bands: List<EqBand> = listOf(
        EqBand(id = 0, frequency = 60f, gainDb = 0f, qFactor = 1.0f),    // Low Shelf/Peaking
        EqBand(id = 1, frequency = 250f, gainDb = 0f, qFactor = 1.414f), // Low-Mid
        EqBand(id = 2, frequency = 1000f, gainDb = 0f, qFactor = 1.414f),// Mid
        EqBand(id = 3, frequency = 4000f, gainDb = 0f, qFactor = 1.414f),// High-Mid
        EqBand(id = 4, frequency = 12000f, gainDb = 0f, qFactor = 1.0f)  // High Shelf/Peaking
    )

    override fun setGain(bandId: Int, gainDb: Float) {
        bands.getOrNull(bandId)?.gainDb = gainDb.coerceIn(-12f, 12f)
    }

    override fun setFrequency(bandId: Int, freq: Float) {
        bands.getOrNull(bandId)?.frequency = freq.coerceIn(20f, 22000f)
    }

    override fun setQFactor(bandId: Int, q: Float) {
        bands.getOrNull(bandId)?.qFactor = q.coerceIn(0.1f, 15f)
    }

    override fun setBandEnabled(bandId: Int, enabled: Boolean) {
        bands.getOrNull(bandId)?.isEnabled = enabled
    }

    override fun reset() {
        // High fidelity parametric defaults
        val defaultFreqs = listOf(60f, 250f, 1000f, 4000f, 12000f)
        val defaultQs = listOf(1.0f, 1.414f, 1.414f, 1.414f, 1.0f)
        bands.forEachIndexed { idx, band ->
            band.gainDb = 0f
            band.frequency = defaultFreqs[idx]
            band.qFactor = defaultQs[idx]
            band.isEnabled = true
            band.resetHistory()
        }
    }

    override fun recalculateFilters(sampleRate: Float) {
        bands.forEach { it.recalculateCoefficients(sampleRate) }
    }

    override fun processStereo(inputL: Float, inputR: Float): Pair<Float, Float> {
        if (!isEnabled) return Pair(inputL, inputR)
        var currentL = inputL
        var currentR = inputR
        for (band in bands) {
            val (newL, newR) = band.process(currentL, currentR)
            currentL = newL
            currentR = newR
        }
        return Pair(currentL, currentR)
    }
}

/**
 * Serialized representation of presets for saving/importing/exporting
 */
data class EqualizerPreset(
    val name: String,
    val isEnabled: Boolean,
    val type: String, // "10band", "31band", "parametric"
    val bandsData: List<EqBandData>
)

data class EqBandData(
    val id: Int,
    val frequency: Float,
    val gainDb: Float,
    val qFactor: Float,
    val isEnabled: Boolean
)

/**
 * Helper manager to export/import/save custom EQ presets
 */
object EqualizerPresetManager {
    private val moshi = Moshi.Builder().build()
    private val listType = Types.newParameterizedType(List::class.java, EqualizerPreset::class.java)
    private val adapter = moshi.adapter<List<EqualizerPreset>>(listType)

    fun exportPresetToJson(preset: EqualizerPreset): String {
        val singleAdapter = moshi.adapter(EqualizerPreset::class.java)
        return singleAdapter.toJson(preset)
    }

    fun importPresetFromJson(json: String): EqualizerPreset? {
        return try {
            val singleAdapter = moshi.adapter(EqualizerPreset::class.java)
            singleAdapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    fun savePresetToFile(context: Context, filename: String, preset: EqualizerPreset): Boolean {
        return try {
            val file = File(context.filesDir, "eq_presets/$filename.json")
            file.parentFile?.mkdirs()
            file.writeText(exportPresetToJson(preset))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun loadPresetFromFile(context: Context, filename: String): EqualizerPreset? {
        return try {
            val file = File(context.filesDir, "eq_presets/$filename.json")
            if (file.exists()) {
                importPresetFromJson(file.readText())
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
