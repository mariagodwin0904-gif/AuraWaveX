package com.chrissygodwin.aurawavex.dsp

import java.util.concurrent.ConcurrentHashMap

/**
 * Standardizes thread-safe parameter routing, validation, and real-time coefficient updates
 * for both equalizers and individual DSP modules.
 */
object ParameterManager {
    private val parameterBounds = ConcurrentHashMap<String, ParameterSpec>()

    init {
        // Core parameter specs with safe physical boundaries
        parameterBounds["master_intensity"] = ParameterSpec("master_intensity", 0f, 1f, 0.7f)
        parameterBounds["eq_gain"] = ParameterSpec("eq_gain", -12f, 12f, 0f)
        parameterBounds["eq_q_factor"] = ParameterSpec("eq_q_factor", 0.1f, 15f, 1.414f)
        parameterBounds["module_strength"] = ParameterSpec("module_strength", 0f, 1f, 0.5f)
    }

    /**
     * Updates an individual module's settings in DspCore
     */
    fun updateModuleParameter(moduleId: String, isEnabled: Boolean, strength: Float) {
        val spec = parameterBounds["module_strength"] ?: return
        val clampedStrength = strength.coerceIn(spec.minVal, spec.maxVal)
        
        val module = DspCore.getModule(moduleId)
        if (module != null) {
            module.isEnabled = isEnabled
            module.strength = clampedStrength
            ProcessingManager.syncExecutionChain()
        }
    }

    /**
     * Update active equalizer's band configurations safely
     */
    fun updateEqualizerBand(bandId: Int, gainDb: Float, qFactor: Float = 1.414f, frequencyHz: Float? = null) {
        val gainSpec = parameterBounds["eq_gain"] ?: return
        val qSpec = parameterBounds["eq_q_factor"] ?: return

        val eq = DspCore.activeEqualizer
        eq.setGain(bandId, gainDb.coerceIn(gainSpec.minVal, gainSpec.maxVal))
        eq.setQFactor(bandId, qFactor.coerceIn(qSpec.minVal, qSpec.maxVal))
        if (frequencyHz != null) {
            eq.setFrequency(bandId, frequencyHz.coerceIn(20f, 22000f))
        }
        
        // Triggers coefficient recalculations (usually done in real-time)
        eq.recalculateFilters(44100f) // Recalculate using active fallback
    }

    data class ParameterSpec(
        val name: String,
        val minVal: Float,
        val maxVal: Float,
        val defaultVal: Float
    )
}
