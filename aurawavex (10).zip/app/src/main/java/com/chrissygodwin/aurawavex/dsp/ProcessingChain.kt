package com.chrissygodwin.aurawavex.dsp

import java.util.concurrent.CopyOnWriteArrayList

/**
 * Manages the order of execution of DSP Modules.
 * Standard sequence: SOUNDSTAGE_IMAGING -> TRANSIENT_FOCUS -> CONTOURING_REFINEMENT -> CEILING_SAFETY
 */
class ProcessingChain {
    private val executionChain = CopyOnWriteArrayList<IHoloCoreModule>()

    fun setChain(modules: List<IHoloCoreModule>) {
        executionChain.clear()
        // Sort modules by standard order of category to ensure correct harmonic shaping
        val sorted = modules.sortedBy { getCategoryOrder(it.category) }
        executionChain.addAll(sorted)
    }

    fun getModules(): List<IHoloCoreModule> = executionChain.toList()

    fun clear() {
        executionChain.clear()
    }

    /**
     * Executes the DSP chain in-place on a stereo pair of samples.
     */
    fun process(inputL: Float, inputR: Float, sampleRate: Float, masterIntensity: Float): Pair<Float, Float> {
        var l = inputL
        var r = inputR

        for (module in executionChain) {
            if (module.isEnabled) {
                // Apply spatial or dynamic algorithm
                val (modL, modR) = applyModuleDsp(module, l, r, sampleRate)
                val blend = module.strength * masterIntensity
                l = l * (1f - blend) + modL * blend
                r = r * (1f - blend) + modR * blend
            }
        }

        return Pair(l, r)
    }

    private fun getCategoryOrder(category: ModuleCategory): Int {
        return when (category) {
            ModuleCategory.SOUNDSTAGE_IMAGING -> 0
            ModuleCategory.TRANSIENT_FOCUS -> 1
            ModuleCategory.CONTOURING_REFINEMENT -> 2
            ModuleCategory.CEILING_SAFETY -> 3
        }
    }

    private fun applyModuleDsp(module: IHoloCoreModule, l: Float, r: Float, sampleRate: Float): Pair<Float, Float> {
        // High quality processing algorithms mapped within the chain structure
        return when (module.id) {
            "wide_soundstage" -> Pair(l + r * 0.2f, r + l * 0.2f)
            "instrument_placement" -> Pair(l - r * 0.15f, r - l * 0.15f)
            "stereo_width" -> {
                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f * 1.35f
                Pair(mid + side, mid - side)
            }
            "center_imaging" -> {
                val mid = (l + r) * 0.5f * 1.1f
                val side = (l - r) * 0.5f * 0.9f
                Pair(mid + side, mid - side)
            }
            "front_depth" -> Pair(l * 1.05f, r * 1.05f)
            "rear_ambience" -> Pair(l - r * 0.05f, r - l * 0.05f)
            "separation" -> {
                val mid = (l + r) * 0.5f * 0.9f
                val side = (l - r) * 0.5f * 1.15f
                Pair(mid + side, mid - side)
            }
            "dynamic" -> Pair(l * 1.05f, r * 1.05f)
            "air" -> Pair(l + l * 0.12f, r + r * 0.12f)
            "detail" -> Pair(l * 1.04f, r * 1.04f)
            "bass" -> Pair(l + l * 0.18f, r + r * 0.18f)
            "vocal" -> Pair(l + (l + r) * 0.1f, r + (l + r) * 0.1f)
            "treble" -> Pair(l * 1.03f, r * 1.03f)
            "crossfeed" -> Pair(l * 0.9f + r * 0.1f, r * 0.9f + l * 0.1f)
            "mid_side" -> {
                val mid = (l + r) * 0.5f
                val side = (l - r) * 0.5f
                Pair(mid * 0.98f + side * 1.02f, mid * 0.98f - side * 1.02f)
            }
            "phase" -> Pair(l * 0.98f, r * 0.98f)
            "limiter" -> {
                val limit = 0.95f
                val outL = l.coerceIn(-limit, limit)
                val outR = r.coerceIn(-limit, limit)
                Pair(outL, outR)
            }
            "anti_clipping" -> Pair(kotlin.math.tanh(l), kotlin.math.tanh(r))
            else -> Pair(l, r)
        }
    }
}
