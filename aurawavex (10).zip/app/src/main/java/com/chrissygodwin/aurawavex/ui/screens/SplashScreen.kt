package com.chrissygodwin.aurawavex.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.ui.theme.AmoledBlack
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onSplashComplete: () -> Unit
) {
    // Logo entrance animation
    val scale = remember { Animatable(0.4f) }
    val alpha = remember { Animatable(0.0f) }

    // Ambient pulsing animation
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    LaunchedEffect(key1 = true) {
        // Run entrance animations in parallel
        delay(200)
        scale.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing)
        )
        alpha.animateTo(
            targetValue = 1.0f,
            animationSpec = tween(durationMillis = 1000)
        )
        // Elegant freeze before entering home
        delay(1200)
        onSplashComplete()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AmoledBlack),
        contentAlignment = Alignment.Center
    ) {
        // Background Subtle Gradient Glow
        Box(
            modifier = Modifier
                .size(400.dp)
                .alpha(0.15f)
                .background(
                    Brush.radialGradient(
                        colors = listOf(NeonLimeGreen, Color.Transparent),
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier
                .alpha(alpha.value)
                .scale(scale.value)
        ) {
            // Elegant Canvas-drawn Logo (Double nested ring with geometric wave)
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val radius = size.minDimension / 2f
                    val centerOffset = center

                    // Outer futuristic tick marks/circle
                    drawCircle(
                        brush = Brush.sweepGradient(listOf(RoyalBlue, NeonLimeGreen, RoyalBlue)),
                        radius = radius,
                        center = centerOffset,
                        style = Stroke(width = 2.dp.toPx())
                    )

                    // Inner geometric rings
                    drawCircle(
                        color = RoyalBlue.copy(alpha = 0.4f),
                        radius = radius - 15.dp.toPx(),
                        center = centerOffset,
                        style = Stroke(width = 1.dp.toPx())
                    )

                    // Wave Core
                    val path = androidx.compose.ui.graphics.Path()
                    val waveY = centerOffset.y
                    val waveWidth = radius * 1.2f
                    val startX = centerOffset.x - waveWidth / 2f

                    path.moveTo(startX, waveY)
                    path.cubicTo(
                        startX + waveWidth * 0.25f, waveY - 20.dp.toPx(),
                        startX + waveWidth * 0.25f, waveY + 20.dp.toPx(),
                        startX + waveWidth * 0.5f, waveY
                    )
                    path.cubicTo(
                        startX + waveWidth * 0.75f, waveY - 20.dp.toPx(),
                        startX + waveWidth * 0.75f, waveY + 20.dp.toPx(),
                        startX + waveWidth, waveY
                    )

                    drawPath(
                        path = path,
                        color = NeonLimeGreen,
                        style = Stroke(width = 4.dp.toPx())
                    )
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Main App Branding
            Text(
                text = "AURA\u2022WAVEX",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 36.sp,
                    letterSpacing = 6.sp
                ),
                color = TextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Secondary HoloCore brand line
            Text(
                text = "POWERED BY HOLOCORE\u2122",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    fontWeight = FontWeight.Bold
                ),
                color = NeonLimeGreen,
                textAlign = TextAlign.Center
            )
        }
    }
}
