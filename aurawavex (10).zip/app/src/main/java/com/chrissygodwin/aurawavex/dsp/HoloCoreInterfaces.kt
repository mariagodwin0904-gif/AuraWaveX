package com.chrissygodwin.aurawavex.dsp

/**
 * High-performance, production-ready interface for all independent processing modules
 * in the HoloCore™ DSP Engine. Enables precise thread-safe configurations.
 */
interface IHoloCoreModule {
    val id: String
    val name: String
    val description: String
    val category: ModuleCategory
    var isEnabled: Boolean
    var strength: Float

    /**
     * Resets the module to its pristine default state.
     */
    fun reset()
}

enum class ModuleCategory {
    SOUNDSTAGE_IMAGING,
    TRANSIENT_FOCUS,
    CONTOURING_REFINEMENT,
    CEILING_SAFETY
}

/**
 * Interface representing external output target configurations and hardware compensation mechanisms.
 * Prepared for USB DAC asynchronous digital streams, internal DAC physical drivers, and Bluetooth LDAC/AAC.
 */
interface IDacExtension {
    val targetType: DacTargetType
    val connectionName: String
    val isAvailable: Boolean
    val clockSource: String
    val outputVoltage: String
    val latencyCompensationMs: Int

    /**
     * Calibrates phase alignment and acoustic delay for the specific transducer type.
     */
    fun calibrateAcousticPath(sampleRate: Int, channels: Int)
}

enum class DacTargetType {
    INTERNAL_DAC,
    USB_DAC_ASYNCHRONOUS,
    BLUETOOTH_TRANSMITTER,
    WIRED_ANALOG_STAGE
}

/**
 * Bridge interface preparing the HoloCore™ engine for high-performance low-latency Native DSP
 * integration using Android Oboe, AAudio, or custom C/C++ OpenSL ES engines.
 */
interface INativeDspBridge {
    val isNativeLibraryLoaded: Boolean
    val bufferSizeFrames: Int
    val isLowLatencyPathActive: Boolean

    /**
     * Direct JNI pass-through for sub-millisecond audio block rendering.
     */
    fun processNativeStereo(inputL: FloatArray, inputR: FloatArray, outputL: FloatArray, outputR: FloatArray, frameCount: Int): Boolean
}

/**
 * Interface preparing HoloCore™ for future AI-driven real-time acoustic scene categorization
 * and dynamic background adjustment.
 */
interface IAiAudioProcessor {
    val isModelCompiled: Boolean
    val inferenceLatencyMs: Float
    val currentEnvironmentClassification: String

    /**
     * Dynamically adjusts spatial coefficients based on real-time neural ambient analysis.
     */
    fun adaptDspCoefficients(spectralDensity: FloatArray, temporalFlux: Float): Map<String, Float>
}

/**
 * Personalized Hearing Profile standard, utilizing precision fitting curves to compensate
 * for individual audiometric characteristics.
 */
interface IPersonalizedHearingProfile {
    val profileId: String
    val ownerName: String
    val correctionCurvesL: FloatArray // 10-band correction factors for left ear
    val correctionCurvesR: FloatArray // 10-band correction factors for right ear
    val isCalibrated: Boolean

    /**
     * Applies precise multi-band corrective amplification matching the user's specific hearing profile.
     */
    fun applyCorrectiveFitting(leftSample: Float, rightSample: Float): Pair<Float, Float>
}
