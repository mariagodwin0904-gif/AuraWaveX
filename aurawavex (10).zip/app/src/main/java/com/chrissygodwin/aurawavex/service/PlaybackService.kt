package com.chrissygodwin.aurawavex.service

import android.app.PendingIntent
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.chrissygodwin.aurawavex.MainActivity

class PlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private var exoPlayer: ExoPlayer? = null
    private lateinit var holoCoreAudioProcessor: HoloCoreAudioProcessor

    companion object {
        private var activeProcessor: HoloCoreAudioProcessor? = null
        
        fun updateDsp(enabled: Boolean, profileIndex: Int, intensity: Float) {
            activeProcessor?.updateDspSettings(enabled, profileIndex, intensity)
        }

        fun updateDspModule(id: String, enabled: Boolean, strength: Float) {
            activeProcessor?.updateModule(id, enabled, strength)
        }
    }

    override fun onCreate() {
        super.onCreate()
        
        holoCoreAudioProcessor = HoloCoreAudioProcessor()
        activeProcessor = holoCoreAudioProcessor
        
        // Setup renderers factory with our custom AudioProcessor in the AudioSink
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): androidx.media3.exoplayer.audio.AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(holoCoreAudioProcessor))
                    .build()
            }
        }
        
        // Build ExoPlayer with automated audio focus management and pause on unplug/noisy detection
        val playerBuilder = ExoPlayer.Builder(this, renderersFactory)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .setUsage(C.USAGE_MEDIA)
                    .build(),
                true // Handles Audio Focus automatically!
            )
            .setHandleAudioBecomingNoisy(true) // Pauses automatically when headphones are unplugged!
            
        exoPlayer = playerBuilder.build()

        // Setup MediaSession with Activity PendingIntent for notification and lock screen launch actions
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        
        exoPlayer?.let { player ->
            mediaSession = MediaSession.Builder(this, player)
                .setSessionActivity(pendingIntent)
                .build()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onDestroy() {
        activeProcessor = null
        mediaSession?.run {
            player.release()
            release()
            mediaSession = null
        }
        exoPlayer = null
        super.onDestroy()
    }
}
