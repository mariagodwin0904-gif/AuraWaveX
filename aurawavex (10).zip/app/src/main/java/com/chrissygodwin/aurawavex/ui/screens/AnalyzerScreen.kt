package com.chrissygodwin.aurawavex.ui.screens

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.ui.components.HoloCard
import com.chrissygodwin.aurawavex.ui.theme.AmoledBlack
import com.chrissygodwin.aurawavex.ui.theme.CardBackground
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel
import kotlin.math.sin

@Composable
fun AnalyzerScreen(
    viewModel: AudioViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    // Real-time animation ticking
    val infiniteTransition = rememberInfiniteTransition(label = "fft_anim")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "fft_offset"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Column(modifier = Modifier.fillMaxWidth()) {
            Text(
                text = "HoloCore™ Analyzer",
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimary
            )
            Text(
                text = "REAL-TIME FAST FOURIER TRANSFORM (FFT)",
                style = MaterialTheme.typography.labelMedium,
                color = NeonLimeGreen
            )
        }

        // Live Analyzer Canvas Card
        HoloCard {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "32-BAND FFT SPECTRUM",
                        style = MaterialTheme.typography.labelMedium,
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "96 dB RANGE",
                        style = MaterialTheme.typography.labelMedium,
                        color = NeonLimeGreen,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Waveform FFT Canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(AmoledBlack)
                        .border(1.dp, Color(0xFF1C1C1E), RoundedCornerShape(8.dp))
                        .testTag("fft_analyzer_canvas")
                ) {
                    val width = size.width
                    val height = size.height

                    // Draw grids
                    val gridColor = Color(0xFF121212)
                    for (i in 1..8) {
                        val gridX = i * (width / 9)
                        drawLine(gridColor, Offset(gridX, 0f), Offset(gridX, height), 1f)
                        val gridY = i * (height / 9)
                        drawLine(gridColor, Offset(0f, gridY), Offset(width, gridY), 1f)
                    }

                    // Draw center db levels
                    drawLine(Color(0xFF2C2C2E), Offset(0f, height * 0.5f), Offset(width, height * 0.5f), 1f)

                    // Draw bouncing frequency bars
                    val totalBars = 32
                    val gap = 6f
                    val barWidth = (width - (totalBars - 1) * gap) / totalBars

                    for (i in 0 until totalBars) {
                        val x = i * (barWidth + gap)

                        // Calculate mock heights based on sine wave mathematical noise that shifts over time if track is playing
                        val activePhase = if (uiState.isPlaying) waveOffset else 0f
                        val baseScale = sin((i.toFloat() / totalBars) * Math.PI).toFloat() // curve frequencies
                        val noise = sin(i * 1.5 + activePhase * 0.4).toFloat() * 0.35f + 0.65f
                        val rawHeight = height * baseScale * noise * 0.85f
                        val barHeight = rawHeight.coerceIn(8f, height - 10f)

                        // Dual accent gradient fill
                        drawRect(
                            brush = Brush.verticalGradient(
                                colors = listOf(NeonLimeGreen, RoyalBlue),
                                startY = height - barHeight,
                                endY = height
                            ),
                            topLeft = Offset(x, height - barHeight),
                            size = Size(barWidth, barHeight)
                        )

                        // Bouncing peak dots (Reference hold effect)
                        val peakY = (height - barHeight - 12f).coerceIn(4f, height - 4f)
                        drawCircle(
                            color = NeonLimeGreen.copy(alpha = 0.6f),
                            radius = barWidth / 2.5f,
                            center = Offset(x + barWidth / 2f, peakY)
                        )
                    }
                }

                // Frequency scale
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val scale = listOf("20Hz", "100Hz", "500Hz", "1kHz", "5kHz", "10kHz", "20kHz")
                    scale.forEach { freq ->
                        Text(
                            text = freq,
                            style = MaterialTheme.typography.labelMedium,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        // Stats card
        HoloCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Jitter Deviation Rate",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Calculated phase stability deviation in femtoseconds.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
                Text(
                    text = "< 0.08 fs",
                    style = MaterialTheme.typography.labelLarge,
                    color = NeonLimeGreen,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
