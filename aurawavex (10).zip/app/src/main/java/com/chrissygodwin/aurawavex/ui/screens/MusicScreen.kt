package com.chrissygodwin.aurawavex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Album
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlaylistAdd
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.QueueMusic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Style
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.data.PlaylistEntity
import com.chrissygodwin.aurawavex.ui.theme.CardBackground
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.ui.theme.TextTertiary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel
import com.chrissygodwin.aurawavex.viewmodel.TrackInfo

@Composable
fun MusicScreen(
    viewModel: AudioViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()

    // Screen navigation within Library tabs
    var selectedGroup by remember { mutableStateOf<String?>(null) }
    var selectedGroupType by remember { mutableStateOf<String?>(null) } // "album", "artist", "genre", "folder", "playlist"
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("") }
    var showAddToPlaylistDialog by remember { mutableStateOf<TrackInfo?>(null) }

    val tabs = listOf(
        "Songs", "Albums", "Artists", "Genres", "Folders", 
        "Favorites", "Recently Added", "Recently Played", "Playlists"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Library Title Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Studio Library",
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-1).sp
                    ),
                    color = TextPrimary
                )
                Text(
                    text = "BIT-PERFECT HIGH-RESOLUTION SOURCE FILES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = NeonLimeGreen,
                    fontSize = 10.sp
                )
            }

            // High-Speed Diagnostic scan trigger
            IconButton(
                onClick = { viewModel.scanDeviceStorage() },
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkGraphite)
                    .border(1.dp, Color.White.copy(alpha = 0.05f), CircleShape)
                    .testTag("library_scan_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Scan Media",
                    tint = NeonLimeGreen,
                    modifier = Modifier.size(20.dp)
                )
            }
        }

        // Action Quick Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Load Demo Songs Trigger
            Button(
                onClick = { viewModel.loadDemoMusic() },
                colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .testTag("load_demo_button")
            ) {
                Icon(Icons.Default.QueueMusic, contentDescription = null, tint = RoyalBlue, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Demo Hi-Res Catalog", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            // Wipe Cache trigger
            Button(
                onClick = { viewModel.clearScannedLibrary() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C1010)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp)
                    .testTag("wipe_library_button")
            ) {
                Icon(Icons.Default.Delete, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Wipe Scanned Cache", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        // Interactive Live Search Box
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            placeholder = { Text("Search title, artist, or album...", color = TextSecondary, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = TextSecondary, modifier = Modifier.size(20.dp)) },
            trailingIcon = {
                if (uiState.searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Default.Close, contentDescription = "Clear", tint = TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedBorderColor = NeonLimeGreen,
                unfocusedBorderColor = Color.White.copy(alpha = 0.08f),
                focusedContainerColor = DarkGraphite,
                unfocusedContainerColor = DarkGraphite
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(12.dp))
                .testTag("library_search")
        )

        // If a Group Subview is selected (e.g., viewing tracks in Album "Absolute Zero")
        if (selectedGroup != null && selectedGroupType != null) {
            val groupTitle = selectedGroup ?: ""
            val groupType = selectedGroupType ?: ""
            
            // Get tracks matching subgroup
            val filteredGroupTracks = when (groupType) {
                "album" -> uiState.scannedTracks.filter { it.album == groupTitle }
                "artist" -> uiState.scannedTracks.filter { it.artist == groupTitle }
                "genre" -> uiState.scannedTracks.filter { it.genre == groupTitle }
                "folder" -> uiState.scannedTracks.filter { it.folder == groupTitle }
                "playlist" -> uiState.playlistTracks
                else -> emptyList()
            }.filter {
                it.title.contains(uiState.searchQuery, ignoreCase = true) ||
                it.artist.contains(uiState.searchQuery, ignoreCase = true)
            }

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Return header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            selectedGroup = null
                            selectedGroupType = null
                            viewModel.selectPlaylist(null)
                        }
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = NeonLimeGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "BACK TO LIBRARY / $groupType.uppercase()",
                        color = NeonLimeGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = groupTitle,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )

                if (filteredGroupTracks.isEmpty()) {
                    LibraryEmptyState("No matching tracks in this group.")
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        itemsIndexed(filteredGroupTracks) { index, track ->
                            TrackRowItem(
                                track = track,
                                isPlaying = uiState.isPlaying && uiState.currentTrack.filePath == track.filePath,
                                isCurrent = uiState.currentTrack.filePath == track.filePath,
                                onTrackClick = {
                                    viewModel.setPlaybackQueue(filteredGroupTracks, index)
                                },
                                onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                onAddToPlaylist = { showAddToPlaylistDialog = track }
                            )
                        }
                    }
                }
            }
        } else {
            // Main Library Tabbed Interface
            // Scrollable Pill Selector Tabs
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(tabs) { tab ->
                    val isSelected = uiState.activeLibraryTab == tab
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) NeonLimeGreen else DarkGraphite)
                            .border(
                                width = 1.dp,
                                color = if (isSelected) Color.Transparent else Color.White.copy(alpha = 0.05f),
                                shape = RoundedCornerShape(20.dp)
                            )
                            .clickable {
                                viewModel.setActiveLibraryTab(tab)
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .testTag("tab_$tab")
                    ) {
                        Text(
                            text = tab,
                            color = if (isSelected) Color.Black else TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Active Tab render
            Box(modifier = Modifier.weight(1f)) {
                if (uiState.isScanning) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("SCANNING STORAGE VOLUMES...", color = NeonLimeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Mapping high-resolution indices and caching audio metadata.", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                } else {
                    when (uiState.activeLibraryTab) {
                        "Songs" -> {
                            val list = uiState.scannedTracks.filter {
                                it.title.contains(uiState.searchQuery, ignoreCase = true) ||
                                it.artist.contains(uiState.searchQuery, ignoreCase = true) ||
                                it.album.contains(uiState.searchQuery, ignoreCase = true)
                            }
                            if (list.isEmpty()) {
                                LibraryEmptyState("No local songs scanned. Connect OTG storage or inject the Demo catalog.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    itemsIndexed(list) { index, track ->
                                        TrackRowItem(
                                            track = track,
                                            isPlaying = uiState.isPlaying && uiState.currentTrack.filePath == track.filePath,
                                            isCurrent = uiState.currentTrack.filePath == track.filePath,
                                            onTrackClick = {
                                                viewModel.setPlaybackQueue(list, index)
                                            },
                                            onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                            onAddToPlaylist = { showAddToPlaylistDialog = track }
                                        )
                                    }
                                }
                            }
                        }

                        "Albums" -> {
                            val albums = uiState.scannedTracks
                                .groupBy { it.album }
                                .filter { it.key.contains(uiState.searchQuery, ignoreCase = true) }
                            if (albums.isEmpty()) {
                                LibraryEmptyState("No albums found.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(albums.keys.toList()) { albumName ->
                                        val albumTracks = albums[albumName] ?: emptyList()
                                        val artist = albumTracks.firstOrNull()?.artist ?: "Various Artists"
                                        val hiResCount = albumTracks.count { it.isHiRes }

                                        LibraryCategoryCard(
                                            title = albumName,
                                            subtitle = "$artist  •  ${albumTracks.size} Track(s)",
                                            isHiRes = hiResCount > 0,
                                            icon = Icons.Default.Album,
                                            onClick = {
                                                selectedGroup = albumName
                                                selectedGroupType = "album"
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        "Artists" -> {
                            val artists = uiState.scannedTracks
                                .groupBy { it.artist }
                                .filter { it.key.contains(uiState.searchQuery, ignoreCase = true) }
                            if (artists.isEmpty()) {
                                LibraryEmptyState("No artists found.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(artists.keys.toList()) { artistName ->
                                        val artistTracks = artists[artistName] ?: emptyList()
                                        val hiResCount = artistTracks.count { it.isHiRes }

                                        LibraryCategoryCard(
                                            title = artistName,
                                            subtitle = "${artistTracks.size} Track(s)",
                                            isHiRes = hiResCount > 0,
                                            icon = Icons.Default.Person,
                                            onClick = {
                                                selectedGroup = artistName
                                                selectedGroupType = "artist"
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        "Genres" -> {
                            val genres = uiState.scannedTracks
                                .groupBy { it.genre }
                                .filter { it.key.contains(uiState.searchQuery, ignoreCase = true) }
                            if (genres.isEmpty()) {
                                LibraryEmptyState("No genres found.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(genres.keys.toList()) { genreName ->
                                        val genreTracks = genres[genreName] ?: emptyList()
                                        val hiResCount = genreTracks.count { it.isHiRes }

                                        LibraryCategoryCard(
                                            title = genreName,
                                            subtitle = "${genreTracks.size} Track(s)",
                                            isHiRes = hiResCount > 0,
                                            icon = Icons.Default.Style,
                                            onClick = {
                                                selectedGroup = genreName
                                                selectedGroupType = "genre"
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        "Folders" -> {
                            val folders = uiState.scannedTracks
                                .groupBy { it.folder }
                                .filter { it.key.contains(uiState.searchQuery, ignoreCase = true) }
                            if (folders.isEmpty()) {
                                LibraryEmptyState("No directories mapped.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    items(folders.keys.toList()) { folderName ->
                                        val folderTracks = folders[folderName] ?: emptyList()
                                        val hiResCount = folderTracks.count { it.isHiRes }

                                        LibraryCategoryCard(
                                            title = folderName,
                                            subtitle = "${folderTracks.size} Track(s)  •  Storage",
                                            isHiRes = hiResCount > 0,
                                            icon = Icons.Default.Folder,
                                            onClick = {
                                                selectedGroup = folderName
                                                selectedGroupType = "folder"
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        "Favorites" -> {
                            val favs = uiState.favorites.filter {
                                it.title.contains(uiState.searchQuery, ignoreCase = true) ||
                                it.artist.contains(uiState.searchQuery, ignoreCase = true)
                            }
                            if (favs.isEmpty()) {
                                LibraryEmptyState("No favorite songs added yet. Tap heart icon inside player.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    itemsIndexed(favs) { index, track ->
                                        TrackRowItem(
                                            track = track,
                                            isPlaying = uiState.isPlaying && uiState.currentTrack.filePath == track.filePath,
                                            isCurrent = uiState.currentTrack.filePath == track.filePath,
                                            onTrackClick = {
                                                viewModel.setPlaybackQueue(favs, index)
                                            },
                                            onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                            onAddToPlaylist = { showAddToPlaylistDialog = track }
                                        )
                                    }
                                }
                            }
                        }

                        "Recently Added" -> {
                            val recent = uiState.recentlyAdded.filter {
                                it.title.contains(uiState.searchQuery, ignoreCase = true) ||
                                it.artist.contains(uiState.searchQuery, ignoreCase = true)
                            }
                            if (recent.isEmpty()) {
                                LibraryEmptyState("No songs indexed recently.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    itemsIndexed(recent) { index, track ->
                                        TrackRowItem(
                                            track = track,
                                            isPlaying = uiState.isPlaying && uiState.currentTrack.filePath == track.filePath,
                                            isCurrent = uiState.currentTrack.filePath == track.filePath,
                                            onTrackClick = {
                                                viewModel.setPlaybackQueue(recent, index)
                                            },
                                            onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                            onAddToPlaylist = { showAddToPlaylistDialog = track }
                                        )
                                    }
                                }
                            }
                        }

                        "Recently Played" -> {
                            val recent = uiState.recentlyPlayed.filter {
                                it.title.contains(uiState.searchQuery, ignoreCase = true) ||
                                it.artist.contains(uiState.searchQuery, ignoreCase = true)
                            }
                            if (recent.isEmpty()) {
                                LibraryEmptyState("No tracks played yet.")
                            } else {
                                LazyColumn(
                                    verticalArrangement = Arrangement.spacedBy(10.dp),
                                    modifier = Modifier.fillMaxSize()
                                ) {
                                    itemsIndexed(recent) { index, track ->
                                        TrackRowItem(
                                            track = track,
                                            isPlaying = uiState.isPlaying && uiState.currentTrack.filePath == track.filePath,
                                            isCurrent = uiState.currentTrack.filePath == track.filePath,
                                            onTrackClick = {
                                                viewModel.setPlaybackQueue(recent, index)
                                            },
                                            onFavoriteToggle = { viewModel.toggleFavorite(track) },
                                            onAddToPlaylist = { showAddToPlaylistDialog = track }
                                        )
                                    }
                                }
                            }
                        }

                        "Playlists" -> {
                            Column(
                                modifier = Modifier.fillMaxSize(),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                // Add Playlist Button
                                Button(
                                    onClick = { showCreatePlaylistDialog = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("create_playlist_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, tint = NeonLimeGreen)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Create High-Res Playlist", color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                val playlists = uiState.playlists.filter { it.name.contains(uiState.searchQuery, ignoreCase = true) }
                                if (playlists.isEmpty()) {
                                    LibraryEmptyState("No user playlists created yet.")
                                } else {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(10.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        items(playlists) { playlist ->
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(DarkGraphite)
                                                    .clickable {
                                                        viewModel.selectPlaylist(playlist)
                                                        selectedGroup = playlist.name
                                                        selectedGroupType = "playlist"
                                                    }
                                                    .padding(14.dp),
                                                verticalAlignment = Alignment.CenterVertically,
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                                    Icon(
                                                        imageVector = Icons.Default.PlaylistPlay,
                                                        contentDescription = "Playlist",
                                                        tint = NeonLimeGreen,
                                                        modifier = Modifier.size(24.dp)
                                                    )
                                                    Spacer(modifier = Modifier.width(14.dp))
                                                    Column {
                                                        Text(
                                                            text = playlist.name,
                                                            color = TextPrimary,
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 14.sp
                                                        )
                                                        Text(
                                                            text = "Studio Mix  •  Click to view",
                                                            color = TextSecondary,
                                                            fontSize = 11.sp
                                                        )
                                                    }
                                                }

                                                IconButton(
                                                    onClick = { viewModel.deletePlaylist(playlist.id) },
                                                    modifier = Modifier.testTag("delete_playlist_${playlist.id}")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Default.Delete,
                                                        contentDescription = "Delete Playlist",
                                                        tint = Color.Red.copy(alpha = 0.7f),
                                                        modifier = Modifier.size(18.dp)
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Dynamic Playlist Creation Dialog
    if (showCreatePlaylistDialog) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable { showCreatePlaylistDialog = false },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .width(320.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                    .clickable(enabled = false) {}
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "NEW HIGH-RES PLAYLIST",
                    color = NeonLimeGreen,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                OutlinedTextField(
                    value = playlistNameInput,
                    onValueChange = { playlistNameInput = it },
                    placeholder = { Text("E.g., Audiophile Jazz Master", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonLimeGreen,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.1f),
                        focusedContainerColor = CardBackground,
                        unfocusedContainerColor = CardBackground
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("playlist_dialog_input")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { showCreatePlaylistDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancel", color = TextSecondary)
                    }

                    Button(
                        onClick = {
                            if (playlistNameInput.isNotBlank()) {
                                viewModel.createPlaylist(playlistNameInput)
                                playlistNameInput = ""
                                showCreatePlaylistDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonLimeGreen),
                        modifier = Modifier.weight(1f).testTag("playlist_dialog_confirm")
                    ) {
                        Text("Create", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // Add To Playlist Dialog
    if (showAddToPlaylistDialog != null) {
        val activeTrack = showAddToPlaylistDialog!!
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.85f))
                .clickable { showAddToPlaylistDialog = null },
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier
                    .width(320.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(CardBackground)
                    .border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp))
                    .clickable(enabled = false) {}
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "ADD TO PLAYLIST",
                    color = NeonLimeGreen,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )

                Text(
                    text = activeTrack.title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                if (uiState.playlists.isEmpty()) {
                    Text(
                        text = "Create a playlist first from the Playlists tab.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                    ) {
                        items(uiState.playlists) { playlist ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(DarkGraphite)
                                    .clickable {
                                        viewModel.addTrackToPlaylist(playlist.id, activeTrack.filePath)
                                        showAddToPlaylistDialog = null
                                    }
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.PlaylistAdd, contentDescription = null, tint = NeonLimeGreen, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(playlist.name, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }

                Button(
                    onClick = { showAddToPlaylistDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = DarkGraphite),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Close", color = TextSecondary)
                }
            }
        }
    }
}

@Composable
fun TrackRowItem(
    track: TrackInfo,
    isPlaying: Boolean,
    isCurrent: Boolean,
    onTrackClick: () -> Unit,
    onFavoriteToggle: () -> Unit,
    onAddToPlaylist: () -> Unit
) {
    val borderColor = if (isCurrent) NeonLimeGreen.copy(alpha = 0.5f) else Color.White.copy(alpha = 0.03f)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (isCurrent) Color(0xFF131F10) else DarkGraphite)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp))
            .clickable { onTrackClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Status indicator
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(if (isCurrent) NeonLimeGreen else Color(0xFF1C1C1E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isPlaying) Icons.Default.MusicNote else Icons.Default.MusicNote,
                contentDescription = "Track",
                tint = if (isCurrent) Color.Black else TextSecondary,
                modifier = Modifier.size(18.dp)
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Text labels
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = track.title,
                    color = if (isCurrent) NeonLimeGreen else TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (track.isHiRes) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(NeonLimeGreen.copy(alpha = 0.15f))
                            .padding(horizontal = 4.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "HI-RES",
                            fontSize = 6.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonLimeGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "${track.artist}  •  ${track.album}",
                color = TextSecondary,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Action Column (Technical properties, Playlist addition, Favorite toggle)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.End
        ) {
            // Technical format spec
            Column(
                horizontalAlignment = Alignment.End,
                modifier = Modifier.padding(end = 4.dp)
            ) {
                Text(
                    text = track.format.uppercase(),
                    color = if (track.isHiRes) NeonLimeGreen else RoyalBlue,
                    fontSize = 8.5.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = track.sampleRate.replace(" kHz", "k").replace(" MHz", "M"),
                    color = TextSecondary,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Playlist add button
            IconButton(
                onClick = onAddToPlaylist,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.PlaylistAdd,
                    contentDescription = "Add to playlist",
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Heart favoriter
            IconButton(
                onClick = onFavoriteToggle,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = if (track.isFavorite) Color.Red else TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun LibraryCategoryCard(
    title: String,
    subtitle: String,
    isHiRes: Boolean,
    icon: ImageVector,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(DarkGraphite)
            .border(1.dp, Color.White.copy(alpha = 0.03f), RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF1C1C1E)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (isHiRes) NeonLimeGreen else RoyalBlue,
                modifier = Modifier.size(22.dp)
            )
        }

        Spacer(modifier = Modifier.width(14.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = title,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )

                if (isHiRes) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(3.dp))
                            .background(NeonLimeGreen.copy(alpha = 0.12f))
                            .padding(horizontal = 4.dp, vertical = 1.5.dp)
                    ) {
                        Text(
                            text = "HI-RES",
                            fontSize = 6.5.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = NeonLimeGreen
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun LibraryEmptyState(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp, horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.MusicNote,
                contentDescription = null,
                tint = TextTertiary,
                modifier = Modifier.size(40.dp)
            )
            Text(
                text = message,
                color = TextSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                lineHeight = 18.sp
            )
        }
    }
}
