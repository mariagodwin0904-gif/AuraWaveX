package com.chrissygodwin.aurawavex.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FormatSize
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.outlined.Snooze
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.ui.theme.AmoledBlack
import com.chrissygodwin.aurawavex.ui.theme.CardBackground
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.GlowBlue
import com.chrissygodwin.aurawavex.ui.theme.GlowGreen
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.ui.theme.TextTertiary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel
import com.chrissygodwin.aurawavex.viewmodel.TrackInfo
import java.util.Locale

@Composable
fun FullScreenPlayer(
    viewModel: AudioViewModel,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val track = uiState.currentTrack
    val scrollState = rememberScrollState()

    var showSpeedMenu by remember { mutableStateOf(false) }
    var showTimerMenu by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(AmoledBlack)
    ) {
        // Subtle background glow corresponding to track hi-res state
        val glowBrush = Brush.radialGradient(
            colors = if (track.isHiRes) {
                listOf(GlowGreen.copy(alpha = 0.25f), Color.Transparent)
            } else {
                listOf(GlowBlue.copy(alpha = 0.25f), Color.Transparent)
            },
            radius = 1200f
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(glowBrush)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("player_collapse_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Collapse",
                        tint = TextPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NOW PLAYING",
                        style = MaterialTheme.typography.labelMedium.copy(
                            letterSpacing = 2.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = TextSecondary,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "STUDIO DAC SOURCE",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (track.isHiRes) NeonLimeGreen else RoyalBlue,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 9.sp
                    )
                }

                // Sleep Timer Trigger
                Box {
                    IconButton(
                        onClick = { showTimerMenu = true },
                        modifier = Modifier.testTag("player_timer_button")
                    ) {
                        Icon(
                            imageVector = if (uiState.sleepTimerRemainingSec > 0) Icons.Default.Snooze else Icons.Default.Snooze,
                            contentDescription = "Sleep Timer",
                            tint = if (uiState.sleepTimerRemainingSec > 0) NeonLimeGreen else TextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    DropdownMenu(
                        expanded = showTimerMenu,
                        onDismissRequest = { showTimerMenu = false },
                        modifier = Modifier.background(CardBackground)
                    ) {
                        val timers = listOf(
                            "Off" to 0,
                            "15 Minutes" to 15,
                            "30 Minutes" to 30,
                            "45 Minutes" to 45,
                            "60 Minutes" to 60
                        )
                        timers.forEach { (label, mins) ->
                            DropdownMenuItem(
                                text = { Text(label, color = TextPrimary) },
                                onClick = {
                                    viewModel.startSleepTimer(mins)
                                    showTimerMenu = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Large Glassmorphic Album Art
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .padding(12.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(DarkGraphite)
                    .border(
                        width = 1.5.dp,
                        color = if (track.isHiRes) NeonLimeGreen.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.1f),
                        shape = RoundedCornerShape(24.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                // Atmospheric visualizer ring inside the art block
                Box(
                    modifier = Modifier
                        .size(140.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                colors = listOf(RoyalBlue, NeonLimeGreen, RoyalBlue)
                            )
                        )
                        .border(4.dp, AmoledBlack, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MusicNote,
                        contentDescription = "Album Art",
                        tint = TextPrimary,
                        modifier = Modifier.size(48.dp)
                    )
                }

                // Sleep Timer Remaining Badge
                if (uiState.sleepTimerRemainingSec > 0) {
                    val minutes = uiState.sleepTimerRemainingSec / 60
                    val seconds = uiState.sleepTimerRemainingSec % 60
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(16.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.Black.copy(alpha = 0.8f))
                            .border(1.dp, NeonLimeGreen.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = String.format(Locale.getDefault(), "⏱ %02d:%02d", minutes, seconds),
                            color = NeonLimeGreen,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Title, Artist and Favorite Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = track.title,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${track.artist}  •  ${track.album}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                IconButton(
                    onClick = { viewModel.toggleFavorite(track) },
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("player_favorite")
                ) {
                    Icon(
                        imageVector = if (track.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = if (track.isFavorite) Color.Red else TextPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Progress Bar (Slider)
            Column(modifier = Modifier.fillMaxWidth()) {
                Slider(
                    value = uiState.playbackProgress,
                    onValueChange = { viewModel.seekTo(it) },
                    colors = SliderDefaults.colors(
                        activeTrackColor = if (track.isHiRes) NeonLimeGreen else RoyalBlue,
                        inactiveTrackColor = TextTertiary,
                        thumbColor = TextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("player_progress_slider")
                )

                // Elapsed and remaining times
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    val elapsedSec = (uiState.playbackProgress * track.durationSec).toInt()
                    val remainingSec = (track.durationSec - elapsedSec).coerceAtLeast(0)

                    Text(
                        text = formatTime(elapsedSec),
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "-${formatTime(remainingSec)}",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Interactive Player Controls (Shuffle, Previous, Play/Pause, Next, Repeat)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Shuffle
                IconButton(
                    onClick = { viewModel.toggleShuffle() },
                    modifier = Modifier.testTag("player_shuffle")
                ) {
                    Icon(
                        imageVector = Icons.Default.Shuffle,
                        contentDescription = "Shuffle",
                        tint = if (uiState.shuffleEnabled) NeonLimeGreen else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Previous
                IconButton(
                    onClick = { viewModel.previousTrack() },
                    modifier = Modifier.testTag("player_previous")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipPrevious,
                        contentDescription = "Previous",
                        tint = TextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Play / Pause (Large Circular Button)
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(if (track.isHiRes) NeonLimeGreen else RoyalBlue)
                        .clickable { viewModel.togglePlayback() }
                        .testTag("player_play_pause"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (uiState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Play/Pause",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }

                // Next
                IconButton(
                    onClick = { viewModel.nextTrack() },
                    modifier = Modifier.testTag("player_next")
                ) {
                    Icon(
                        imageVector = Icons.Default.SkipNext,
                        contentDescription = "Next",
                        tint = TextPrimary,
                        modifier = Modifier.size(32.dp)
                    )
                }

                // Repeat Mode Selector
                IconButton(
                    onClick = { viewModel.cycleRepeatMode() },
                    modifier = Modifier.testTag("player_repeat")
                ) {
                    val repeatIcon = if (uiState.repeatMode == "One") Icons.Default.RepeatOne else Icons.Default.Repeat
                    Icon(
                        imageVector = repeatIcon,
                        contentDescription = "Repeat",
                        tint = if (uiState.repeatMode != "None") NeonLimeGreen else TextSecondary,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Speed Selector Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(DarkGraphite)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "Playback Speed",
                        tint = TextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAYBACK SPEED",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                }

                Box {
                    Text(
                        text = "${uiState.playbackSpeed}x",
                        color = NeonLimeGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clickable { showSpeedMenu = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("player_speed_trigger")
                    )

                    DropdownMenu(
                        expanded = showSpeedMenu,
                        onDismissRequest = { showSpeedMenu = false },
                        modifier = Modifier.background(CardBackground)
                    ) {
                        val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                        speeds.forEach { speed ->
                            DropdownMenuItem(
                                text = { Text("${speed}x", color = TextPrimary) },
                                onClick = {
                                    viewModel.changePlaybackSpeed(speed)
                                    showSpeedMenu = false
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Hi-Res Technical Bento Diagnostics Card (No DSP applied, Bit-perfect read-out)
            Text(
                text = "TECHNICAL METADATA READOUT (BIT-PERFECT)",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary,
                fontSize = 10.sp,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
            )

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(DarkGraphite)
                    .border(
                        width = 1.dp,
                        color = Color.White.copy(alpha = 0.05f),
                        shape = RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    // Badge and Status Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (track.isHiRes) NeonLimeGreen else Color(0xFF2C2C2E))
                                .padding(horizontal = 8.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = if (track.isHiRes) "STUDIO HI-RES AUDIO" else "STANDARD PCM",
                                color = if (track.isHiRes) Color.Black else TextSecondary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }

                        Text(
                            text = track.format.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = if (track.isHiRes) NeonLimeGreen else RoyalBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }

                    // Grid Columns of diagnostics
                    Row(modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.weight(1f)) {
                            TechnicalStatLabel("CODEC PROTOCOL")
                            TechnicalStatValue(track.codec)

                            Spacer(modifier = Modifier.height(10.dp))

                            TechnicalStatLabel("BITRATE")
                            TechnicalStatValue(track.bitrate)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            TechnicalStatLabel("SAMPLE RESOLUTION")
                            TechnicalStatValue(track.sampleRate)

                            Spacer(modifier = Modifier.height(10.dp))

                            TechnicalStatLabel("BIT DEPTH MODE")
                            TechnicalStatValue(track.bitDepth)
                        }
                    }

                    // Direct Stream / Decoupled Warning
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "HoloCore™ hardware mapping is active. Jitter minimization femtoclock alignment is set to BIT-PERFECT bypass. DSP effects are disabled to prevent resampling.",
                            fontSize = 9.sp,
                            color = TextSecondary,
                            lineHeight = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(48.dp))
        }
    }
}

@Composable
fun TechnicalStatLabel(label: String) {
    Text(
        text = label,
        fontSize = 8.sp,
        fontWeight = FontWeight.Bold,
        color = TextSecondary,
        letterSpacing = 1.sp
    )
}

@Composable
fun TechnicalStatValue(value: String) {
    Text(
        text = value,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary,
        fontFamily = FontFamily.Monospace,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis
    )
}

fun formatTime(seconds: Int): String {
    val m = seconds / 60
    val s = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", m, s)
}
