package com.chrissygodwin.aurawavex.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tracks")
data class TrackEntity(
    @PrimaryKey val filePath: String,
    val title: String,
    val artist: String,
    val album: String,
    val genre: String,
    val folder: String,
    val durationSec: Int,
    val dateAdded: Long,
    val sampleRate: String,
    val bitDepth: String,
    val format: String,
    val bitrate: String,
    val codec: String,
    val isHiRes: Boolean,
    val isFavorite: Boolean,
    val playCount: Int,
    val lastPlayed: Long,
    val albumArtUri: String?
)
