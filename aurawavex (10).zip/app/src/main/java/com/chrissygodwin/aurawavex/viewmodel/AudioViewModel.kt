package com.chrissygodwin.aurawavex.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.chrissygodwin.aurawavex.data.AudioDatabase
import com.chrissygodwin.aurawavex.data.PlaylistEntity
import com.chrissygodwin.aurawavex.data.TrackRepository
import com.chrissygodwin.aurawavex.data.MediaScanner
import com.chrissygodwin.aurawavex.service.PlayerRepository
import com.chrissygodwin.aurawavex.service.PlaybackService
import com.chrissygodwin.aurawavex.dsp.DspCore
import com.chrissygodwin.aurawavex.dsp.ParameterManager
import com.chrissygodwin.aurawavex.dsp.eq.EqBand
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TrackInfo(
    val title: String,
    val artist: String,
    val album: String,
    val sampleRate: String,
    val bitDepth: String,
    val format: String,
    val durationSec: Int,
    val filePath: String = "",
    val isHiRes: Boolean = false,
    val codec: String = "",
    val bitrate: String = "",
    val albumArtUri: String? = null,
    val isFavorite: Boolean = false,
    val genre: String = "Local Audio",
    val folder: String = "Root",
    val dateAdded: Long = 0L,
    val playCount: Int = 0,
    val lastPlayed: Long = 0L
)

data class DacStatus(
    val isConnected: Boolean,
    val deviceName: String,
    val activeFilter: String,
    val clockSource: String,
    val voltageOut: String,
    val currentVolume: Int
)

data class HoloCoreProfile(
    val name: String,
    val description: String,
    val intensity: Float,
    val isEnabled: Boolean
)

data class HoloCoreModule(
    val id: String,
    val name: String,
    val description: String,
    val isEnabled: Boolean,
    val strength: Float,
    val defaultValue: Float = 0.5f
)

data class AudioUiState(
    val currentTrack: TrackInfo,
    val dacStatus: DacStatus,
    val holoCoreEnabled: Boolean,
    val activeProfileIndex: Int,
    val profiles: List<HoloCoreProfile>,
    val modules: List<HoloCoreModule> = emptyList(),
    val isPlaying: Boolean,
    val playbackProgress: Float, // 0.0f to 1.0f
    val holoCoreIntensity: Float = 0.7f,
    val holoCoreDepth: Float = 0.6f,
    val holoCoreWidth: Float = 0.7f,
    val holoCoreImmersion: Float = 0.5f,
    val holoCoreNaturalness: Float = 0.8f,
    val processingQuality: String = "Ultra Precision (64-bit)",
    val holoCorePreviewActive: Boolean = false,
    val previewBypass: Boolean = false,
    
    // Scanned Library State
    val scannedTracks: List<TrackInfo> = emptyList(),
    val favorites: List<TrackInfo> = emptyList(),
    val recentlyAdded: List<TrackInfo> = emptyList(),
    val recentlyPlayed: List<TrackInfo> = emptyList(),
    val playlists: List<PlaylistEntity> = emptyList(),
    val playlistTracks: List<TrackInfo> = emptyList(),
    val selectedPlaylist: PlaylistEntity? = null,
    val searchQuery: String = "",
    val activeLibraryTab: String = "Songs",
    val queue: List<TrackInfo> = emptyList(),
    val currentQueueIndex: Int = 0,
    val shuffleEnabled: Boolean = false,
    val repeatMode: String = "All", // "None", "All", "One"
    val playbackSpeed: Float = 1.0f,
    val sleepTimerRemainingSec: Int = 0,
    val isScanning: Boolean = false,
    val isFullScreenPlayerVisible: Boolean = false,
    val eqType: String = "10band",
    val eqEnabled: Boolean = true,
    val eqBands: List<EqBand> = emptyList(),
    val eqPresets: List<String> = emptyList(),
    val selectedEqPresetIndex: Int = 0
)

class AudioViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AudioDatabase.getInstance(application)
    private val repository = TrackRepository(
        trackDao = database.trackDao(),
        playlistDao = database.playlistDao(),
        mediaScanner = MediaScanner(application)
    )

    private val filterList = listOf(
        "Linear Phase Fast Roll-off",
        "Minimum Phase Slow Roll-off",
        "Apodizing Fast Roll-off",
        "HoloCore™ Zero-Phase Hybrid"
    )

    private val profileList = listOf(
        HoloCoreProfile("Standard Pass", "Bypasses all digital shaping, delivering the raw master file with bit-perfect alignment.", 0.0f, false),
        HoloCoreProfile("Pure Path™", "Deactivates non-essential background processes, minimizing RF interference and jitter.", 0.8f, true),
        HoloCoreProfile("Tube Warmth", "Injects subtle even-order harmonic richness mimicking premium reference triode amplifiers.", 0.6f, true),
        HoloCoreProfile("Holographic Stage", "Expands spatial cues and phase integrity for an immersive, deeply layered soundstage.", 0.9f, true),
        HoloCoreProfile("Electrostatic Edge", "Accelerates transient response and micro-detail resolution for hyper-realistic speed.", 0.7f, true)
    )

    private fun loadInitialModules(application: Application): List<HoloCoreModule> {
        val sharedPrefs = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        val list = listOf(
            HoloCoreModule("wide_soundstage", "Wide Soundstage", "Expands the physical boundary limits of the acoustic room stage.", true, 0.5f),
            HoloCoreModule("instrument_placement", "Instrument Placement", "Presents a stable physical azimuth and elevation positioning stage.", true, 0.5f),
            HoloCoreModule("separation", "Instrument Separation", "Unclutters dense arrangements for surgical definition.", true, 0.5f),
            HoloCoreModule("stereo_width", "Stereo Width", "Widens the side-field acoustic cues without losing energy.", true, 0.5f),
            HoloCoreModule("center_imaging", "Center Imaging", "Pinpoints phantom center vocal alignment amid wide fields.", true, 0.5f),
            HoloCoreModule("front_depth", "Front Depth", "Projects early localized reflection walls to extend front-field layering.", true, 0.5f),
            HoloCoreModule("rear_ambience", "Rear Ambience", "Weaves diffuse rear-wall acoustic reflections for an enveloping field.", true, 0.5f),
            HoloCoreModule("dynamic", "Dynamic Enhancement", "Restores transient attack and dynamic contrast ranges.", true, 0.5f),
            HoloCoreModule("detail", "Micro Detail Recovery", "Accentuates and extracts fine micro-details and instrumental air.", true, 0.5f),
            HoloCoreModule("air", "Air Enhancement", "Injects micro-acoustic room breathing at extreme high frequencies.", true, 0.5f),
            HoloCoreModule("bass", "Controlled Bass", "Tightens sub-bass contouring while eliminating mid-bass bloat.", true, 0.5f),
            HoloCoreModule("vocal", "Vocal Focus", "Elevates midrange presence and intelligibility of vocal lines.", true, 0.5f),
            HoloCoreModule("treble", "Treble Refinement", "Polishes high frequencies for maximum clarity without glare.", true, 0.5f),
            HoloCoreModule("crossfeed", "Crossfeed", "Blends acoustic head-shadow cues to minimize ear fatigue.", true, 0.5f),
            HoloCoreModule("mid_side", "Mid/Side Processing", "Decouples wide side-channel fields from mono center fields.", true, 0.5f),
            HoloCoreModule("phase", "Phase Optimization", "Aligns driver propagation delays for transient coherence.", true, 0.5f),
            HoloCoreModule("limiter", "Limiter", "Acoustically limits signal peaks to maximize perceptual loudness.", true, 0.5f),
            HoloCoreModule("anti_clipping", "Anti-Clipping", "Employs soft-knee saturation to prevent physical transducer distortion.", true, 0.5f)
        )
        return list.map { def ->
            val enabled = sharedPrefs.getBoolean("mod_enabled_${def.id}", def.isEnabled)
            val strength = sharedPrefs.getFloat("mod_strength_${def.id}", def.strength)
            PlaybackService.updateDspModule(def.id, enabled, strength)
            def.copy(isEnabled = enabled, strength = strength)
        }
    }

    private val _uiState = MutableStateFlow(
        AudioUiState(
            currentTrack = TrackInfo(
                title = "Starlight Resonance",
                artist = "Chrissy Godwin",
                album = "HoloCore Sessions Vol. I",
                sampleRate = "384 kHz",
                bitDepth = "32-bit",
                format = "FLAC DXD",
                durationSec = 284,
                filePath = "demo://starlight_resonance.flac",
                isHiRes = true,
                codec = "Free Lossless Audio Codec",
                bitrate = "1420 kbps",
                genre = "Synthwave",
                folder = "Hi-Res Masters"
            ),
            dacStatus = DacStatus(
                isConnected = true,
                deviceName = "HoloCore™ Elite USB DAC",
                activeFilter = "HoloCore™ Zero-Phase Hybrid",
                clockSource = "Internal OCXO Femto Clock",
                voltageOut = "4.0 Vrms Balanced",
                currentVolume = 78
            ),
            holoCoreEnabled = true,
            activeProfileIndex = 1,
            profiles = profileList,
            modules = loadInitialModules(application),
            isPlaying = false,
            playbackProgress = 0.0f,
            holoCoreIntensity = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getFloat("holocore_master_intensity", 0.7f),
            holoCoreDepth = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getFloat("holocore_master_depth", 0.6f),
            holoCoreWidth = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getFloat("holocore_master_width", 0.7f),
            holoCoreImmersion = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getFloat("holocore_master_immersion", 0.5f),
            holoCoreNaturalness = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getFloat("holocore_master_naturalness", 0.8f),
            processingQuality = application.getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
                .getString("holocore_processing_quality", "Ultra Precision (64-bit)") ?: "Ultra Precision (64-bit)",
            holoCorePreviewActive = false,
            previewBypass = false,
            eqType = "10band",
            eqEnabled = true,
            eqBands = DspCore.activeEqualizer.bands,
            eqPresets = listOf("Reference (Flat)", "HoloCore™ Glow", "Symphonic Stage", "Acoustic Air", "Direct Master"),
            selectedEqPresetIndex = 1
        )
    )
    val uiState: StateFlow<AudioUiState> = _uiState.asStateFlow()

    private val playerRepository = PlayerRepository(application, repository)

    init {
        // Synchronize with PlayerRepository state
        viewModelScope.launch {
            playerRepository.currentTrack.collectLatest { track ->
                if (track != null) {
                    _uiState.update { it.copy(currentTrack = track) }
                }
            }
        }

        viewModelScope.launch {
            playerRepository.isPlaying.collectLatest { playing ->
                _uiState.update { it.copy(isPlaying = playing) }
            }
        }

        viewModelScope.launch {
            playerRepository.playbackProgress.collectLatest { progress ->
                _uiState.update { it.copy(playbackProgress = progress) }
            }
        }

        viewModelScope.launch {
            playerRepository.queue.collectLatest { q ->
                _uiState.update { it.copy(queue = q) }
            }
        }

        viewModelScope.launch {
            playerRepository.currentQueueIndex.collectLatest { index ->
                _uiState.update { it.copy(currentQueueIndex = index) }
            }
        }

        viewModelScope.launch {
            playerRepository.shuffleEnabled.collectLatest { enabled ->
                _uiState.update { it.copy(shuffleEnabled = enabled) }
            }
        }

        viewModelScope.launch {
            playerRepository.repeatMode.collectLatest { mode ->
                _uiState.update { it.copy(repeatMode = mode) }
            }
        }

        viewModelScope.launch {
            playerRepository.playbackSpeed.collectLatest { speed ->
                _uiState.update { it.copy(playbackSpeed = speed) }
            }
        }

        viewModelScope.launch {
            playerRepository.sleepTimerRemainingSec.collectLatest { remaining ->
                _uiState.update { it.copy(sleepTimerRemainingSec = remaining) }
            }
        }

        // Collect DB updates in real-time
        viewModelScope.launch {
            repository.getTracksFlow().collectLatest { tracks ->
                _uiState.update { it.copy(scannedTracks = tracks) }
                if (tracks.isEmpty()) {
                    repository.injectDemoTracks()
                }
            }
        }

        viewModelScope.launch {
            repository.getFavoritesFlow().collectLatest { favorites ->
                _uiState.update { it.copy(favorites = favorites) }
            }
        }

        viewModelScope.launch {
            repository.getRecentlyAddedFlow().collectLatest { recent ->
                _uiState.update { it.copy(recentlyAdded = recent) }
            }
        }

        viewModelScope.launch {
            repository.getRecentlyPlayedFlow().collectLatest { recent ->
                _uiState.update { it.copy(recentlyPlayed = recent) }
            }
        }

        viewModelScope.launch {
            repository.getPlaylistsFlow().collectLatest { playlists ->
                _uiState.update { it.copy(playlists = playlists) }
            }
        }

        // Initialize DSP sync
        triggerDspUpdate()
    }

    private fun triggerDspUpdate() {
        val state = _uiState.value
        val enabled = state.holoCoreEnabled && !state.previewBypass
        val profileIndex = state.activeProfileIndex
        val intensity = state.holoCoreIntensity
        PlaybackService.updateDsp(enabled, profileIndex, intensity)
    }

    // Playback Controller
    fun playTrack(track: TrackInfo) {
        playerRepository.playTrack(track)
    }

    fun togglePlayback() {
        playerRepository.togglePlayback()
    }

    fun seekTo(progress: Float) {
        playerRepository.seekTo(progress)
    }

    fun nextTrack() {
        playerRepository.nextTrack()
    }

    fun previousTrack() {
        playerRepository.previousTrack()
    }

    // Controls
    fun toggleShuffle() {
        playerRepository.toggleShuffle()
    }

    fun cycleRepeatMode() {
        playerRepository.cycleRepeatMode()
    }

    fun changePlaybackSpeed(speed: Float) {
        playerRepository.changePlaybackSpeed(speed)
    }

    fun startSleepTimer(minutes: Int) {
        playerRepository.startSleepTimer(minutes)
    }

    // Volume & Attenuation
    fun changeVolume(volume: Int) {
        val clamped = volume.coerceIn(0, 100)
        _uiState.update {
            it.copy(
                dacStatus = it.dacStatus.copy(currentVolume = clamped)
            )
        }
    }

    fun cycleDacFilter() {
        val currentFilter = _uiState.value.dacStatus.activeFilter
        val nextIndex = (filterList.indexOf(currentFilter) + 1) % filterList.size
        _uiState.update {
            it.copy(
                dacStatus = it.dacStatus.copy(activeFilter = filterList[nextIndex])
            )
        }
    }

    // HoloCore Profile Selection
    fun selectHoloCoreProfile(index: Int) {
        if (index in profileList.indices) {
            _uiState.update {
                it.copy(
                    activeProfileIndex = index,
                    holoCoreEnabled = index > 0
                )
            }
            triggerDspUpdate()
        }
    }

    fun toggleHoloCore(enabled: Boolean) {
        _uiState.update {
            it.copy(
                holoCoreEnabled = enabled,
                activeProfileIndex = if (enabled) 1 else 0
            )
        }
        triggerDspUpdate()
    }

    fun updateHoloCoreIntensity(intensity: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putFloat("holocore_master_intensity", intensity).apply()
        _uiState.update {
            it.copy(holoCoreIntensity = intensity)
        }
        triggerDspUpdate()
    }

    fun updateHoloCoreDepth(depth: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putFloat("holocore_master_depth", depth).apply()
        _uiState.update {
            it.copy(holoCoreDepth = depth)
        }
        triggerDspUpdate()
    }

    fun updateHoloCoreWidth(width: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putFloat("holocore_master_width", width).apply()
        _uiState.update {
            it.copy(holoCoreWidth = width)
        }
        triggerDspUpdate()
    }

    fun updateHoloCoreImmersion(immersion: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putFloat("holocore_master_immersion", immersion).apply()
        _uiState.update {
            it.copy(holoCoreImmersion = immersion)
        }
        triggerDspUpdate()
    }

    fun updateHoloCoreNaturalness(naturalness: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putFloat("holocore_master_naturalness", naturalness).apply()
        _uiState.update {
            it.copy(holoCoreNaturalness = naturalness)
        }
        triggerDspUpdate()
    }

    fun updateProcessingQuality(quality: String) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit().putString("holocore_processing_quality", quality).apply()
        _uiState.update {
            it.copy(processingQuality = quality)
        }
        triggerDspUpdate()
    }

    private var previewJob: Job? = null

    fun toggleHoloCorePreview(enabled: Boolean) {
        previewJob?.cancel()
        _uiState.update { it.copy(holoCorePreviewActive = enabled) }
        
        if (enabled) {
            // Force master switch ON when starting preview
            _uiState.update { it.copy(holoCoreEnabled = true, previewBypass = false) }
            triggerDspUpdate()
            
            previewJob = viewModelScope.launch {
                while (true) {
                    // 2 seconds active (Bypass OFF)
                    _uiState.update { it.copy(previewBypass = false) }
                    triggerDspUpdate()
                    delay(2000)
                    
                    // 2 seconds bypassed (Bypass ON)
                    _uiState.update { it.copy(previewBypass = true) }
                    triggerDspUpdate()
                    delay(2000)
                }
            }
        } else {
            _uiState.update { it.copy(previewBypass = false) }
            triggerDspUpdate()
        }
    }

    fun resetHoloCoreSignature() {
        updateHoloCoreIntensity(0.7f)
        updateHoloCoreDepth(0.6f)
        updateHoloCoreWidth(0.7f)
        updateHoloCoreImmersion(0.5f)
        updateHoloCoreNaturalness(0.8f)
        updateProcessingQuality("Ultra Precision (64-bit)")
        _uiState.update {
            it.copy(
                holoCoreEnabled = true,
                activeProfileIndex = 1,
                holoCorePreviewActive = false,
                previewBypass = false
            )
        }
        previewJob?.cancel()
        triggerDspUpdate()
    }

    fun updateHoloCoreModule(id: String, isEnabled: Boolean, strength: Float) {
        val sharedPrefs = getApplication<Application>().getSharedPreferences("aurawave_prefs", android.content.Context.MODE_PRIVATE)
        sharedPrefs.edit()
            .putBoolean("mod_enabled_$id", isEnabled)
            .putFloat("mod_strength_$id", strength)
            .apply()

        _uiState.update { state ->
            state.copy(
                modules = state.modules.map { mod ->
                    if (mod.id == id) mod.copy(isEnabled = isEnabled, strength = strength) else mod
                }
            )
        }
        PlaybackService.updateDspModule(id, isEnabled, strength)
    }

    fun resetHoloCoreModule(id: String) {
        val module = _uiState.value.modules.find { it.id == id } ?: return
        updateHoloCoreModule(id, true, module.defaultValue)
    }

    fun resetAllHoloCoreModules() {
        _uiState.value.modules.forEach { mod ->
            updateHoloCoreModule(mod.id, true, mod.defaultValue)
        }
    }

    // Media Scanning & DB triggers
    fun scanDeviceStorage() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true) }
            repository.scanDevice()
            _uiState.update { it.copy(isScanning = false) }
        }
    }

    fun loadDemoMusic() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanning = true) }
            repository.injectDemoTracks()
            _uiState.update { it.copy(isScanning = false) }
        }
    }

    fun clearScannedLibrary() {
        viewModelScope.launch {
            repository.clearAllTracks()
            _uiState.update {
                it.copy(
                    scannedTracks = emptyList(),
                    favorites = emptyList(),
                    recentlyAdded = emptyList(),
                    recentlyPlayed = emptyList(),
                    queue = emptyList(),
                    currentQueueIndex = 0
                )
            }
        }
    }

    fun toggleFavorite(track: TrackInfo) {
        viewModelScope.launch {
            val nextState = !track.isFavorite
            repository.toggleFavorite(track.filePath, nextState)
            if (_uiState.value.currentTrack.filePath == track.filePath) {
                _uiState.update { it.copy(currentTrack = it.currentTrack.copy(isFavorite = nextState)) }
            }
            // Update item in local list references
            updateLocalTrackFavorite(track.filePath, nextState)
        }
    }

    private fun updateLocalTrackFavorite(filePath: String, isFav: Boolean) {
        val updateTrack = { t: TrackInfo -> if (t.filePath == filePath) t.copy(isFavorite = isFav) else t }
        _uiState.update { state ->
            state.copy(
                scannedTracks = state.scannedTracks.map(updateTrack),
                favorites = state.favorites.map(updateTrack),
                recentlyAdded = state.recentlyAdded.map(updateTrack),
                recentlyPlayed = state.recentlyPlayed.map(updateTrack),
                queue = state.queue.map(updateTrack)
            )
        }
    }

    // Library UI Helpers
    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun setActiveLibraryTab(tab: String) {
        _uiState.update { it.copy(activeLibraryTab = tab) }
    }

    fun setFullScreenPlayerVisible(visible: Boolean) {
        _uiState.update { it.copy(isFullScreenPlayerVisible = visible) }
    }

    // Playlists Methods
    fun createPlaylist(name: String) {
        viewModelScope.launch {
            repository.createPlaylist(name)
        }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            repository.deletePlaylist(playlistId)
            if (_uiState.value.selectedPlaylist?.id == playlistId) {
                _uiState.update { it.copy(selectedPlaylist = null, playlistTracks = emptyList()) }
            }
        }
    }

    fun addTrackToPlaylist(playlistId: Long, trackPath: String) {
        viewModelScope.launch {
            repository.addTrackToPlaylist(playlistId, trackPath)
        }
    }

    fun removeTrackFromPlaylist(playlistId: Long, trackPath: String) {
        viewModelScope.launch {
            repository.removeTrackFromPlaylist(playlistId, trackPath)
        }
    }

    fun selectPlaylist(playlist: PlaylistEntity?) {
        _uiState.update { it.copy(selectedPlaylist = playlist) }
        if (playlist != null) {
            viewModelScope.launch {
                repository.getTracksForPlaylistFlow(playlist.id).collectLatest { tracks ->
                    _uiState.update { it.copy(playlistTracks = tracks) }
                }
            }
        } else {
            _uiState.update { it.copy(playlistTracks = emptyList()) }
        }
    }

    // Update active queue
    fun setPlaybackQueue(newQueue: List<TrackInfo>, activeTrackIndex: Int) {
        playerRepository.setPlaybackQueue(newQueue, activeTrackIndex)
    }

    // Equalizer controls
    fun setEqType(type: String) {
        DspCore.setActiveEqualizerType(type)
        _uiState.update { it.copy(eqType = type, eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    fun setEqEnabled(enabled: Boolean) {
        DspCore.activeEqualizer.isEnabled = enabled
        _uiState.update { it.copy(eqEnabled = enabled) }
    }

    fun updateEqBandGain(bandId: Int, gainDb: Float) {
        ParameterManager.updateEqualizerBand(bandId, gainDb)
        _uiState.update { it.copy(eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    fun updateEqBandFrequency(bandId: Int, freq: Float) {
        val eq = DspCore.activeEqualizer
        ParameterManager.updateEqualizerBand(bandId, eq.bands.getOrNull(bandId)?.gainDb ?: 0f, eq.bands.getOrNull(bandId)?.qFactor ?: 1.414f, freq)
        _uiState.update { it.copy(eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    fun updateEqBandQFactor(bandId: Int, q: Float) {
        val eq = DspCore.activeEqualizer
        ParameterManager.updateEqualizerBand(bandId, eq.bands.getOrNull(bandId)?.gainDb ?: 0f, q)
        _uiState.update { it.copy(eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    fun resetEq() {
        DspCore.activeEqualizer.reset()
        _uiState.update { it.copy(eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    fun applyEqPreset(presetIndex: Int) {
        val eq = DspCore.activeEqualizer
        val bands = eq.bands
        when (presetIndex) {
            0 -> { // Flat
                bands.forEach { it.gainDb = 0f }
            }
            1 -> { // HoloCore™ Glow
                val gains = floatArrayOf(1.5f, 2.2f, 1.0f, -0.5f, -1.5f, 0.5f, 1.8f, 3.0f, 1.5f, 0.5f)
                bands.forEachIndexed { idx, band ->
                    band.gainDb = gains.getOrNull(idx) ?: 0f
                }
            }
            2 -> { // Symphonic Stage
                val gains = floatArrayOf(-2.0f, -1.0f, 0.5f, 1.5f, 2.0f, 1.0f, 0.5f, 1.8f, 2.5f, 3.2f)
                bands.forEachIndexed { idx, band ->
                    band.gainDb = gains.getOrNull(idx) ?: 0f
                }
            }
            3 -> { // Acoustic Air
                val gains = floatArrayOf(0f, -0.5f, -1.2f, -1.0f, 0.5f, 1.2f, 2.0f, 3.5f, 4.2f, 5.0f)
                bands.forEachIndexed { idx, band ->
                    band.gainDb = gains.getOrNull(idx) ?: 0f
                }
            }
            4 -> { // Direct Master
                val gains = floatArrayOf(1.0f, 1.0f, 0f, 0f, -1.0f, -1.0f, 0.5f, 0.5f, 0f, 1.2f)
                bands.forEachIndexed { idx, band ->
                    band.gainDb = gains.getOrNull(idx) ?: 0f
                }
            }
        }
        eq.recalculateFilters(44100f)
        _uiState.update { it.copy(selectedEqPresetIndex = presetIndex, eqBands = DspCore.activeEqualizer.bands.toList()) }
    }

    override fun onCleared() {
        playerRepository.release()
        super.onCleared()
    }
}
