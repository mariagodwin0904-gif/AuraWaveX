package com.chrissygodwin.aurawavex.dsp

import android.content.Context
import com.chrissygodwin.aurawavex.dsp.eq.EqualizerPreset
import com.chrissygodwin.aurawavex.dsp.eq.EqualizerPresetManager
import com.squareup.moshi.Moshi
import java.io.File

/**
 * Manages spatial and equalizer presets, supporting saving, importing, and exporting.
 */
object PresetManager {
    private val moshi = Moshi.Builder().build()

    data class HoloCorePreset(
        val name: String,
        val description: String,
        val masterIntensity: Float,
        val isMasterEnabled: Boolean,
        val equalizerPresetName: String?,
        val modulesStates: Map<String, ModuleState>
    )

    data class ModuleState(
        val id: String,
        val isEnabled: Boolean,
        val strength: Float
    )

    private val builtInPresets = listOf(
        HoloCorePreset(
            name = "AuraWaveX Glow",
            description = "Unlocks full three-dimensional field with subtle tube analog warmth.",
            masterIntensity = 0.85f,
            isMasterEnabled = true,
            equalizerPresetName = "HoloCore™ Glow",
            modulesStates = mapOf(
                "wide_soundstage" to ModuleState("wide_soundstage", true, 0.65f),
                "stereo_width" to ModuleState("stereo_width", true, 0.6f),
                "center_imaging" to ModuleState("center_imaging", true, 0.5f),
                "dynamic" to ModuleState("dynamic", true, 0.7f),
                "detail" to ModuleState("detail", true, 0.8f)
            )
        ),
        HoloCorePreset(
            name = "Symphonic Concert Hall",
            description = "Maximizes soundstage elevation and spatial decay for classical ensembles.",
            masterIntensity = 0.95f,
            isMasterEnabled = true,
            equalizerPresetName = "Symphonic Stage",
            modulesStates = mapOf(
                "wide_soundstage" to ModuleState("wide_soundstage", true, 0.9f),
                "front_depth" to ModuleState("front_depth", true, 0.8f),
                "rear_ambience" to ModuleState("rear_ambience", true, 0.75f),
                "separation" to ModuleState("separation", true, 0.7f)
            )
        ),
        HoloCorePreset(
            name = "Pure Reference Studio",
            description = "Maintains completely flat, pristine transparent signal pathway.",
            masterIntensity = 0.0f,
            isMasterEnabled = false,
            equalizerPresetName = "Reference (Flat)",
            modulesStates = emptyMap()
        )
    )

    fun getBuiltInPresets(): List<HoloCorePreset> = builtInPresets

    /**
     * Applies a HoloCore preset to DspCore and active modules
     */
    fun applyPreset(preset: HoloCorePreset) {
        DspCore.masterEnabled = preset.isMasterEnabled
        DspCore.masterIntensity = preset.masterIntensity

        // Reset modules and apply specific preset states
        DspCore.getAllModules().forEach { mod ->
            val state = preset.modulesStates[mod.id]
            if (state != null) {
                mod.isEnabled = state.isEnabled
                mod.strength = state.strength
            } else {
                mod.isEnabled = false
            }
        }
        ProcessingManager.syncExecutionChain()
    }

    /**
     * Export preset to JSON string
     */
    fun exportPreset(preset: HoloCorePreset): String {
        return moshi.adapter(HoloCorePreset::class.java).toJson(preset)
    }

    /**
     * Import preset from JSON string
     */
    fun importPreset(json: String): HoloCorePreset? {
        return try {
            moshi.adapter(HoloCorePreset::class.java).fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Save custom preset to physical file system
     */
    fun savePresetToFile(context: Context, filename: String, preset: HoloCorePreset): Boolean {
        return try {
            val file = File(context.filesDir, "holocore_presets/$filename.json")
            file.parentFile?.mkdirs()
            file.writeText(exportPreset(preset))
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Load custom preset from physical file system
     */
    fun loadPresetFromFile(context: Context, filename: String): HoloCorePreset? {
        return try {
            val file = File(context.filesDir, "holocore_presets/$filename.json")
            if (file.exists()) {
                importPreset(file.readText())
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }
}
