package com.chrissygodwin.aurawavex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chrissygodwin.aurawavex.ui.components.AudioSpecCard
import com.chrissygodwin.aurawavex.ui.components.AuraWaveform
import com.chrissygodwin.aurawavex.ui.components.CurrentSongCard
import com.chrissygodwin.aurawavex.ui.components.DacStatusGridCard
import com.chrissygodwin.aurawavex.ui.components.HoloCard
import com.chrissygodwin.aurawavex.ui.components.HoloCoreHighlightCard
import com.chrissygodwin.aurawavex.ui.theme.DarkGraphite
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.ui.theme.TextTertiary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel

@Composable
fun HomeScreen(
    viewModel: AudioViewModel,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "AuraWaveX",
                    style = MaterialTheme.typography.headlineMedium.copy(
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-0.5).sp
                    ),
                    color = NeonLimeGreen
                )
                Text(
                    text = "POWERED BY HOLOCORE™",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = TextSecondary
                )
            }

            // Glimmer status circle
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(DarkGraphite)
                    .border(1.dp, Color.White.copy(alpha = 0.1f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(NeonLimeGreen)
                )
            }
        }

        // Center Premium Animated Audio Waveform (Bento Waveform visualizer)
        AuraWaveform(
            isPlaying = uiState.isPlaying,
            intensity = if (uiState.holoCoreEnabled) 1.3f else 0.8f,
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .clip(RoundedCornerShape(32.dp))
                .background(DarkGraphite)
                .border(
                    width = 1.dp,
                    color = Color.White.copy(alpha = 0.05f),
                    shape = RoundedCornerShape(32.dp)
                )
                .testTag("premium_waveform")
        )

        // Interactive Bento Grid
        Column(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Row 1: Large Song Card (Full width of Bento Grid)
            CurrentSongCard(
                track = uiState.currentTrack,
                isPlaying = uiState.isPlaying,
                progress = uiState.playbackProgress,
                onTogglePlay = { viewModel.togglePlayback() },
                onNext = { viewModel.nextTrack() },
                onPrevious = { viewModel.previousTrack() },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("song_card")
            )

            // Row 2: DAC Status Card & Sample Rate Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DacStatusGridCard(
                    isConnected = uiState.dacStatus.isConnected,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("dac_status_card")
                )

                val sampleRateVal = uiState.currentTrack.sampleRate
                val sampleRateSub = if (sampleRateVal.contains("MHz")) "NATIVE DSD" else "NATIVE PCM"
                AudioSpecCard(
                    label = "Sample Rate",
                    value = sampleRateVal.replace(" kHz", "").replace(" MHz", ""),
                    subValue = sampleRateSub,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("sample_rate_card")
                )
            }

            // Row 3: Bit Depth Card & HoloCore Mode Card
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val bitDepthVal = uiState.currentTrack.bitDepth
                val bitDepthSub = if (bitDepthVal.contains("1-bit")) "DIRECT STREAM" else "INTEGER MODE"
                AudioSpecCard(
                    label = "Bit Depth",
                    value = bitDepthVal.replace("-bit", " Bit").replace("1-bit", "1 Bit"),
                    subValue = bitDepthSub,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("bit_depth_card")
                )

                val activeProfileName = uiState.profiles.getOrNull(uiState.activeProfileIndex)?.name ?: "Pure Path™"
                HoloCoreHighlightCard(
                    isEnabled = uiState.holoCoreEnabled,
                    activeProfileName = activeProfileName,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("holocore_highlight_card"),
                    onToggle = { viewModel.toggleHoloCore(!uiState.holoCoreEnabled) }
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "HARDWARE RACK TUNER",
            style = MaterialTheme.typography.labelMedium.copy(
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold
            ),
            color = TextSecondary,
            modifier = Modifier.padding(start = 4.dp)
        )

        // Custom Bento Control Card for Attenuation and Hardware Filtering
        HoloCard(modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Filter Switcher
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(Color(0xFF1E1E1E))
                        .clickable { viewModel.cycleDacFilter() }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "HARDWARE ROLL-OFF FILTER",
                            style = MaterialTheme.typography.labelMedium,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                        Text(
                            text = uiState.dacStatus.activeFilter,
                            style = MaterialTheme.typography.bodyMedium,
                            color = NeonLimeGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Cycle Filter",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Volume slider
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Volume Icon",
                                tint = TextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "MASTER ATTENUATION",
                                style = MaterialTheme.typography.labelMedium,
                                color = TextSecondary,
                                fontSize = 10.sp
                            )
                        }
                        Text(
                            text = "${uiState.dacStatus.currentVolume}%",
                            style = MaterialTheme.typography.labelLarge,
                            color = TextPrimary
                        )
                    }
                    Slider(
                        value = uiState.dacStatus.currentVolume.toFloat(),
                        onValueChange = { viewModel.changeVolume(it.toInt()) },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(
                            activeTrackColor = NeonLimeGreen,
                            inactiveTrackColor = TextTertiary,
                            thumbColor = TextPrimary
                        ),
                        modifier = Modifier
                            .height(24.dp)
                            .testTag("volume_slider")
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}
