package com.chrissygodwin.aurawavex.dsp

import android.content.Context
import android.content.SharedPreferences

/**
 * Handles persistent storing and loading of DSP configs, active profiles,
 * target DAC classes, and custom hardware compensation levels.
 */
class ConfigurationManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("holocore_config_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_MASTER_ENABLED = "master_enabled"
        private const val KEY_MASTER_INTENSITY = "master_intensity"
        private const val KEY_DAC_TARGET = "dac_target_type"
        private const val KEY_OVERSAMPLING = "oversampling_factor"
        private const val KEY_EQ_TYPE = "active_eq_type"
    }

    fun isMasterEnabled(): Boolean {
        return prefs.getBoolean(KEY_MASTER_ENABLED, true)
    }

    fun setMasterEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_MASTER_ENABLED, enabled).apply()
        DspCore.masterEnabled = enabled
    }

    fun getMasterIntensity(): Float {
        return prefs.getFloat(KEY_MASTER_INTENSITY, 0.7f)
    }

    fun setMasterIntensity(intensity: Float) {
        prefs.edit().putFloat(KEY_MASTER_INTENSITY, intensity).apply()
        DspCore.masterIntensity = intensity
    }

    fun getDacTargetType(): String {
        return prefs.getString(KEY_DAC_TARGET, "INTERNAL_DAC") ?: "INTERNAL_DAC"
    }

    fun setDacTargetType(type: String) {
        prefs.edit().putString(KEY_DAC_TARGET, type).apply()
    }

    fun getOversamplingFactor(): Int {
        return prefs.getInt(KEY_OVERSAMPLING, 2) // 1x, 2x, 4x, etc.
    }

    fun setOversamplingFactor(factor: Int) {
        prefs.edit().putInt(KEY_OVERSAMPLING, factor.coerceIn(1, 8)).apply()
    }

    fun getActiveEqType(): String {
        return prefs.getString(KEY_EQ_TYPE, "10band") ?: "10band"
    }

    fun setActiveEqType(type: String) {
        prefs.edit().putString(KEY_EQ_TYPE, type).apply()
        DspCore.setActiveEqualizerType(type)
    }

    /**
     * Persists settings of an individual module
     */
    fun saveModuleSettings(moduleId: String, isEnabled: Boolean, strength: Float) {
        prefs.edit()
            .putBoolean("mod_enabled_$moduleId", isEnabled)
            .putFloat("mod_strength_$moduleId", strength)
            .apply()
    }

    /**
     * Load settings of an individual module
     */
    fun loadModuleSettings(moduleId: String): Pair<Boolean, Float> {
        val enabled = prefs.getBoolean("mod_enabled_$moduleId", true)
        val strength = prefs.getFloat("mod_strength_$moduleId", 0.5f)
        return Pair(enabled, strength)
    }
}
