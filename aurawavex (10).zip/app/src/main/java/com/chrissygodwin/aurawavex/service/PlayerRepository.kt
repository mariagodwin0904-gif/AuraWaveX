package com.chrissygodwin.aurawavex.service

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.chrissygodwin.aurawavex.data.TrackRepository
import com.chrissygodwin.aurawavex.viewmodel.TrackInfo
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray

class PlayerRepository(
    private val context: Context,
    private val trackRepository: TrackRepository
) {
    private val sharedPrefs: SharedPreferences = context.getSharedPreferences("aurawave_prefs", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null

    // State flows representing actual player states
    private val _currentTrack = MutableStateFlow<TrackInfo?>(null)
    val currentTrack: StateFlow<TrackInfo?> = _currentTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackProgress = MutableStateFlow(0f)
    val playbackProgress: StateFlow<Float> = _playbackProgress.asStateFlow()

    private val _queue = MutableStateFlow<List<TrackInfo>>(emptyList())
    val queue: StateFlow<List<TrackInfo>> = _queue.asStateFlow()

    private val _currentQueueIndex = MutableStateFlow(0)
    val currentQueueIndex: StateFlow<Int> = _currentQueueIndex.asStateFlow()

    private val _shuffleEnabled = MutableStateFlow(false)
    val shuffleEnabled: StateFlow<Boolean> = _shuffleEnabled.asStateFlow()

    private val _repeatMode = MutableStateFlow("All") // "None", "All", "One"
    val repeatMode: StateFlow<String> = _repeatMode.asStateFlow()

    private val _playbackSpeed = MutableStateFlow(1.0f)
    val playbackSpeed: StateFlow<Float> = _playbackSpeed.asStateFlow()

    private val _sleepTimerRemainingSec = MutableStateFlow(0)
    val sleepTimerRemainingSec: StateFlow<Int> = _sleepTimerRemainingSec.asStateFlow()

    // Map demo:// tracks to playable online mp3 streams
    private val demoTracksMap = mapOf(
        "demo://starlight_resonance.flac" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3",
        "demo://quantum_resonance.dsf" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3",
        "demo://acoustic_reflection.flac" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3",
        "demo://holographic_space.wav" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3",
        "demo://midnight_ambient.m4a" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3",
        "demo://triode_harmonics.aif" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3",
        "demo://bit_perfect_symphony.flac" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-7.mp3",
        "demo://analog_emulation.dsf" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3",
        "demo://silicon_valleys.opus" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-9.mp3",
        "demo://golden_ear_master.flac" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-10.mp3",
        "demo://noiseless_horizon.flac" to "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-11.mp3"
    )

    private var progressJob: Job? = null
    private var sleepTimerJob: Job? = null

    init {
        initializeController()
        loadPersistedState()
    }

    private fun initializeController() {
        val isRobolectric = System.getProperty("robolectric.class.path") != null ||
                runCatching { Class.forName("org.robolectric.Robolectric") }.isSuccess
        if (isRobolectric) {
            Log.d("PlayerRepository", "Skipping MediaController initialization in Robolectric test environment.")
            return
        }
        val sessionToken = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        controllerFuture = MediaController.Builder(context, sessionToken).buildAsync()
        controllerFuture?.addListener({
            try {
                val controller = controllerFuture?.get() ?: return@addListener
                mediaController = controller
                
                // Set initial controller configs
                controller.shuffleModeEnabled = _shuffleEnabled.value
                controller.repeatMode = getMedia3RepeatMode(_repeatMode.value)
                controller.setPlaybackSpeed(_playbackSpeed.value)
                
                // Add listener to listen to playback status changes
                controller.addListener(object : Player.Listener {
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        super.onMediaItemTransition(mediaItem, reason)
                        val mediaId = mediaItem?.mediaId ?: return
                        val track = _queue.value.find { it.filePath == mediaId }
                        if (track != null) {
                            _currentTrack.value = track
                            val index = _queue.value.indexOf(track)
                            if (index >= 0) {
                                _currentQueueIndex.value = index
                            }
                            scope.launch {
                                trackRepository.registerPlayback(track.filePath)
                                persistCurrentTrack(track)
                            }
                        }
                    }

                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        super.onIsPlayingChanged(isPlaying)
                        _isPlaying.value = isPlaying
                        if (isPlaying) {
                            startProgressLoop()
                        } else {
                            progressJob?.cancel()
                        }
                    }

                    override fun onPlaybackParametersChanged(playbackParameters: PlaybackParameters) {
                        super.onPlaybackParametersChanged(playbackParameters)
                        _playbackSpeed.value = playbackParameters.speed
                        persistPlaybackSpeed(playbackParameters.speed)
                    }

                    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                        super.onShuffleModeEnabledChanged(shuffleModeEnabled)
                        _shuffleEnabled.value = shuffleModeEnabled
                        persistShuffleEnabled(shuffleModeEnabled)
                    }

                    override fun onRepeatModeChanged(repeatMode: Int) {
                        super.onRepeatModeChanged(repeatMode)
                        val modeStr = getRepeatModeString(repeatMode)
                        _repeatMode.value = modeStr
                        persistRepeatMode(modeStr)
                    }
                })

                restoreLastPlayingTrackOnController(controller)

            } catch (e: Exception) {
                Log.e("PlayerRepository", "Failed to connect to MediaController", e)
            }
        }, MoreExecutors.directExecutor())
    }

    private fun startProgressLoop() {
        progressJob?.cancel()
        progressJob = scope.launch {
            while (isActive) {
                val controller = mediaController
                if (controller != null && controller.isPlaying) {
                    val duration = controller.duration
                    val position = controller.currentPosition
                    if (duration > 0) {
                        val progress = position.toFloat() / duration
                        _playbackProgress.value = progress.coerceIn(0f, 1f)
                        persistPlaybackPosition(position)
                    }
                }
                delay(250)
            }
        }
    }

    fun playTrack(track: TrackInfo) {
        val controller = mediaController ?: return
        
        val index = _queue.value.indexOfFirst { it.filePath == track.filePath }
        val finalQueue = if (index >= 0) {
            _queue.value
        } else {
            val newQ = _queue.value.toMutableList()
            newQ.add(track)
            _queue.value = newQ
            newQ
        }
        
        val finalIndex = finalQueue.indexOfFirst { it.filePath == track.filePath }.coerceAtLeast(0)
        _currentQueueIndex.value = finalIndex
        _currentTrack.value = track

        controller.stop()
        controller.clearMediaItems()
        
        val mediaItems = finalQueue.map { qTrack ->
            val playableUri = demoTracksMap[qTrack.filePath] ?: qTrack.filePath
            MediaItem.Builder()
                .setMediaId(qTrack.filePath)
                .setUri(playableUri)
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle(qTrack.title)
                        .setArtist(qTrack.artist)
                        .setAlbumTitle(qTrack.album)
                        .build()
                )
                .build()
        }
        
        controller.setMediaItems(mediaItems, finalIndex, C.TIME_UNSET)
        controller.prepare()
        controller.play()
        
        persistQueue(finalQueue)
        persistCurrentTrack(track)
    }

    fun togglePlayback() {
        val controller = mediaController ?: return
        if (controller.isPlaying) {
            controller.pause()
        } else {
            if (controller.playbackState == Player.STATE_IDLE) {
                val track = _currentTrack.value
                if (track != null) {
                    playTrack(track)
                } else if (_queue.value.isNotEmpty()) {
                    playTrack(_queue.value[0])
                }
            } else {
                controller.play()
            }
        }
    }

    fun seekTo(progress: Float) {
        val controller = mediaController ?: return
        val duration = controller.duration
        if (duration > 0) {
            val position = (progress * duration).toLong()
            controller.seekTo(position)
            _playbackProgress.value = progress
        }
    }

    fun nextTrack() {
        val controller = mediaController ?: return
        if (controller.hasNextMediaItem()) {
            controller.seekToNextMediaItem()
        } else {
            if (_repeatMode.value == "All" && _queue.value.isNotEmpty()) {
                controller.seekTo(0, 0)
            }
        }
    }

    fun previousTrack() {
        val controller = mediaController ?: return
        if (controller.hasPreviousMediaItem()) {
            controller.seekToPreviousMediaItem()
        } else {
            if (_repeatMode.value == "All" && _queue.value.isNotEmpty()) {
                controller.seekTo(_queue.value.size - 1, 0)
            }
        }
    }

    fun toggleShuffle() {
        val controller = mediaController ?: return
        val nextShuffle = !controller.shuffleModeEnabled
        controller.shuffleModeEnabled = nextShuffle
        _shuffleEnabled.value = nextShuffle
    }

    fun cycleRepeatMode() {
        val controller = mediaController ?: return
        val nextMode = when (_repeatMode.value) {
            "None" -> "All"
            "All" -> "One"
            else -> "None"
        }
        controller.repeatMode = getMedia3RepeatMode(nextMode)
        _repeatMode.value = nextMode
    }

    fun changePlaybackSpeed(speed: Float) {
        val controller = mediaController ?: return
        val clampedSpeed = speed.coerceIn(0.5f, 2.0f)
        controller.setPlaybackSpeed(clampedSpeed)
        _playbackSpeed.value = clampedSpeed
    }

    fun startSleepTimer(minutes: Int) {
        sleepTimerJob?.cancel()
        if (minutes == 0) {
            _sleepTimerRemainingSec.value = 0
            return
        }

        _sleepTimerRemainingSec.value = minutes * 60
        sleepTimerJob = scope.launch {
            while (_sleepTimerRemainingSec.value > 0) {
                delay(1000)
                _sleepTimerRemainingSec.update { (it - 1).coerceAtLeast(0) }
            }
            if (_isPlaying.value) {
                togglePlayback()
            }
        }
    }

    fun setPlaybackQueue(newQueue: List<TrackInfo>, activeTrackIndex: Int) {
        if (newQueue.isEmpty()) return
        val clampedIndex = activeTrackIndex.coerceIn(newQueue.indices)
        _queue.value = newQueue
        persistQueue(newQueue)
        playTrack(newQueue[clampedIndex])
    }

    // Persist & Restore Logic
    private fun persistCurrentTrack(track: TrackInfo) {
        sharedPrefs.edit()
            .putString("last_track_path", track.filePath)
            .putString("last_track_title", track.title)
            .putString("last_track_artist", track.artist)
            .putString("last_track_album", track.album)
            .putString("last_track_sample_rate", track.sampleRate)
            .putString("last_track_bit_depth", track.bitDepth)
            .putString("last_track_format", track.format)
            .putInt("last_track_duration", track.durationSec)
            .putBoolean("last_track_hires", track.isHiRes)
            .putString("last_track_codec", track.codec)
            .putString("last_track_bitrate", track.bitrate)
            .putString("last_track_album_art", track.albumArtUri)
            .putBoolean("last_track_fav", track.isFavorite)
            .putString("last_track_genre", track.genre)
            .putString("last_track_folder", track.folder)
            .apply()
    }

    private fun persistPlaybackPosition(positionMs: Long) {
        sharedPrefs.edit().putLong("last_position_ms", positionMs).apply()
    }

    private fun persistPlaybackSpeed(speed: Float) {
        sharedPrefs.edit().putFloat("last_speed", speed).apply()
    }

    private fun persistShuffleEnabled(enabled: Boolean) {
        sharedPrefs.edit().putBoolean("last_shuffle", enabled).apply()
    }

    private fun persistRepeatMode(mode: String) {
        sharedPrefs.edit().putString("last_repeat", mode).apply()
    }

    private fun persistQueue(queueList: List<TrackInfo>) {
        val array = JSONArray()
        for (track in queueList) {
            array.put(track.filePath)
        }
        sharedPrefs.edit().putString("last_queue", array.toString()).apply()
    }

    private fun loadPersistedState() {
        _shuffleEnabled.value = sharedPrefs.getBoolean("last_shuffle", false)
        _repeatMode.value = sharedPrefs.getString("last_repeat", "All") ?: "All"
        _playbackSpeed.value = sharedPrefs.getFloat("last_speed", 1.0f)
        
        val lastTrackPath = sharedPrefs.getString("last_track_path", null)
        if (lastTrackPath != null) {
            val track = TrackInfo(
                filePath = lastTrackPath,
                title = sharedPrefs.getString("last_track_title", "Starlight Resonance") ?: "",
                artist = sharedPrefs.getString("last_track_artist", "Chrissy Godwin") ?: "",
                album = sharedPrefs.getString("last_track_album", "HoloCore Sessions Vol. I") ?: "",
                sampleRate = sharedPrefs.getString("last_track_sample_rate", "384 kHz") ?: "",
                bitDepth = sharedPrefs.getString("last_track_bit_depth", "32-bit") ?: "",
                format = sharedPrefs.getString("last_track_format", "FLAC DXD") ?: "",
                durationSec = sharedPrefs.getInt("last_track_duration", 284),
                isHiRes = sharedPrefs.getBoolean("last_track_hires", true),
                codec = sharedPrefs.getString("last_track_codec", "Free Lossless Audio Codec") ?: "",
                bitrate = sharedPrefs.getString("last_track_bitrate", "1420 kbps") ?: "",
                albumArtUri = sharedPrefs.getString("last_track_album_art", null),
                isFavorite = sharedPrefs.getBoolean("last_track_fav", false),
                genre = sharedPrefs.getString("last_track_genre", "Synthwave") ?: "",
                folder = sharedPrefs.getString("last_track_folder", "Hi-Res Masters") ?: ""
            )
            _currentTrack.value = track
            val lastPos = sharedPrefs.getLong("last_position_ms", 0L)
            if (track.durationSec > 0) {
                _playbackProgress.value = (lastPos.toFloat() / (track.durationSec * 1000f)).coerceIn(0f, 1f)
            }
        }
    }

    private fun restoreLastPlayingTrackOnController(controller: MediaController) {
        val lastTrack = _currentTrack.value ?: return
        val lastQueueString = sharedPrefs.getString("last_queue", null)
        
        scope.launch(Dispatchers.IO) {
            val restoredQueue = mutableListOf<TrackInfo>()
            if (lastQueueString != null) {
                try {
                    val array = JSONArray(lastQueueString)
                    val allTracks = mutableListOf<TrackInfo>()
                    trackRepository.getTracksFlow().collect { tracks ->
                        if (tracks.isNotEmpty()) {
                            allTracks.addAll(tracks)
                            for (i in 0 until array.length()) {
                                val path = array.getString(i)
                                val match = allTracks.find { it.filePath == path }
                                if (match != null) {
                                    restoredQueue.add(match)
                                }
                            }
                            
                            withContext(Dispatchers.Main) {
                                if (restoredQueue.isNotEmpty()) {
                                    _queue.value = restoredQueue
                                    val index = restoredQueue.indexOfFirst { it.filePath == lastTrack.filePath }.coerceAtLeast(0)
                                    _currentQueueIndex.value = index
                                    
                                    val mediaItems = restoredQueue.map { qTrack ->
                                        val playableUri = demoTracksMap[qTrack.filePath] ?: qTrack.filePath
                                        MediaItem.Builder()
                                            .setMediaId(qTrack.filePath)
                                            .setUri(playableUri)
                                            .setMediaMetadata(
                                                MediaMetadata.Builder()
                                                    .setTitle(qTrack.title)
                                                    .setArtist(qTrack.artist)
                                                    .setAlbumTitle(qTrack.album)
                                                    .build()
                                            )
                                            .build()
                                    }
                                    controller.setMediaItems(mediaItems, index, sharedPrefs.getLong("last_position_ms", 0L))
                                    controller.prepare()
                                }
                            }
                            cancel()
                        }
                    }
                } catch (e: Exception) {
                    Log.e("PlayerRepository", "Failed to restore queue", e)
                }
            }
        }
    }

    private fun getMedia3RepeatMode(modeStr: String): Int {
        return when (modeStr) {
            "One" -> Player.REPEAT_MODE_ONE
            "All" -> Player.REPEAT_MODE_ALL
            else -> Player.REPEAT_MODE_OFF
        }
    }

    private fun getRepeatModeString(repeatMode: Int): String {
        return when (repeatMode) {
            Player.REPEAT_MODE_ONE -> "One"
            Player.REPEAT_MODE_ALL -> "All"
            else -> "None"
        }
    }

    fun release() {
        progressJob?.cancel()
        sleepTimerJob?.cancel()
        scope.cancel()
        controllerFuture?.let {
            MediaController.releaseFuture(it)
        }
    }
}
