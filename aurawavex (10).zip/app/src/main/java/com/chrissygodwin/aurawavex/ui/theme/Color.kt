package com.chrissygodwin.aurawavex.ui.theme

import androidx.compose.ui.graphics.Color

// AuraWaveX Premium Palette
val AmoledBlack = Color(0xFF000000)
val DarkGraphite = Color(0xFF121212)
val CardBackground = Color(0xFF1C1C1E)

// Accents
val NeonLimeGreen = Color(0xFFCCFF00)
val RoyalBlue = Color(0xFF3A59D4)

// Text and feedback
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF8E8E93)
val TextTertiary = Color(0xFF48484A)
val GlowGreen = Color(0x33CCFF00)
val GlowBlue = Color(0x223A59D4)

