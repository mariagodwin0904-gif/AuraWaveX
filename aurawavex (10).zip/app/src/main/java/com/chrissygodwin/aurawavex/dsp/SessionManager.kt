package com.chrissygodwin.aurawavex.dsp

import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Manages active audio streaming parameters, calculates latency,
 * track samples rendered, and estimates DSP computational load.
 */
object SessionManager {
    private val activeSampleRate = AtomicInteger(44100)
    private val activeBitDepth = AtomicInteger(16)
    private val totalProcessedFrames = AtomicLong(0)
    private val activeChannels = AtomicInteger(2)
    private var isLowLatencyActive = true

    fun setStreamConfig(sampleRate: Int, bitDepth: Int, channels: Int) {
        activeSampleRate.set(sampleRate)
        activeBitDepth.set(bitDepth)
        activeChannels.set(channels)
    }

    fun getSampleRate(): Int = activeSampleRate.get()
    fun getBitDepth(): Int = activeBitDepth.get()
    fun getChannels(): Int = activeChannels.get()

    fun recordProcessedFrames(frameCount: Int) {
        totalProcessedFrames.addAndGet(frameCount.toLong())
    }

    fun getTotalFrames(): Long = totalProcessedFrames.get()

    fun isLowLatencyPathActive(): Boolean = isLowLatencyActive

    fun setLowLatencyPathActive(active: Boolean) {
        isLowLatencyActive = active
    }

    /**
     * Estimates processing load of HoloCore engine
     */
    fun estimateGflops(): Float {
        // Average FLOPS per sample in our biquad and delay-reflection loops
        val opsPerSample = 320
        val rate = activeSampleRate.get().toFloat()
        val channels = activeChannels.get().toFloat()
        return (opsPerSample * rate * channels) / 1_000_000_000f // Return in GFLOPS
    }

    /**
     * Compute total system playback latency in ms (buffer latency + DSP chain propagation)
     */
    fun getSystemLatencyMs(bufferSizeFrames: Int): Float {
        val rate = activeSampleRate.get().toFloat()
        val bufferLatency = (bufferSizeFrames / rate) * 1000f
        val dspLatency = 0.85f // Extra latency added by our reflection loops
        return bufferLatency + dspLatency
    }
}
