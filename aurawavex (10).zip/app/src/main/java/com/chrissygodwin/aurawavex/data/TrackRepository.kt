package com.chrissygodwin.aurawavex.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import com.chrissygodwin.aurawavex.viewmodel.TrackInfo

class TrackRepository(
    private val trackDao: TrackDao,
    private val playlistDao: PlaylistDao,
    private val mediaScanner: MediaScanner
) {

    // Converts Entity to Domain model
    private fun TrackEntity.toDomain(): TrackInfo {
        return TrackInfo(
            title = title,
            artist = artist,
            album = album,
            sampleRate = sampleRate,
            bitDepth = bitDepth,
            format = format,
            durationSec = durationSec,
            filePath = filePath,
            isHiRes = isHiRes,
            codec = codec,
            bitrate = bitrate,
            albumArtUri = albumArtUri,
            isFavorite = isFavorite,
            genre = genre,
            folder = folder,
            dateAdded = dateAdded,
            playCount = playCount,
            lastPlayed = lastPlayed
        )
    }

    // Converts Domain to Entity model
    private fun TrackInfo.toEntity(): TrackEntity {
        return TrackEntity(
            filePath = filePath,
            title = title,
            artist = artist,
            album = album,
            genre = genre,
            folder = folder,
            durationSec = durationSec,
            dateAdded = dateAdded,
            sampleRate = sampleRate,
            bitDepth = bitDepth,
            format = format,
            bitrate = bitrate,
            codec = codec,
            isHiRes = isHiRes,
            isFavorite = isFavorite,
            playCount = playCount,
            lastPlayed = lastPlayed,
            albumArtUri = albumArtUri
        )
    }

    // Flows
    fun getTracksFlow(): Flow<List<TrackInfo>> =
        trackDao.getAllTracksFlow().map { entities -> entities.map { it.toDomain() } }

    fun getFavoritesFlow(): Flow<List<TrackInfo>> =
        trackDao.getFavoritesFlow().map { entities -> entities.map { it.toDomain() } }

    fun getRecentlyAddedFlow(): Flow<List<TrackInfo>> =
        trackDao.getRecentlyAddedFlow().map { entities -> entities.map { it.toDomain() } }

    fun getRecentlyPlayedFlow(): Flow<List<TrackInfo>> =
        trackDao.getRecentlyPlayedFlow().map { entities -> entities.map { it.toDomain() } }

    fun getPlaylistsFlow(): Flow<List<PlaylistEntity>> =
        playlistDao.getAllPlaylistsFlow()

    fun getTracksForPlaylistFlow(playlistId: Long): Flow<List<TrackInfo>> =
        playlistDao.getTracksForPlaylistFlow(playlistId).map { entities -> entities.map { it.toDomain() } }

    // Scan
    suspend fun scanDevice() = withContext(Dispatchers.IO) {
        val scanned = mediaScanner.scanMedia()
        if (scanned.isNotEmpty()) {
            trackDao.insertTracks(scanned)
            // Clean up files that no longer exist on disk
            val paths = scanned.map { it.filePath }
            trackDao.deleteStaleTracks(paths)
        }
    }

    // Toggle Favorite
    suspend fun toggleFavorite(filePath: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        trackDao.updateFavorite(filePath, isFavorite)
    }

    // Register Playback
    suspend fun registerPlayback(filePath: String) = withContext(Dispatchers.IO) {
        trackDao.incrementPlayCount(filePath, System.currentTimeMillis())
    }

    // Playlists
    suspend fun createPlaylist(name: String): Long = withContext(Dispatchers.IO) {
        playlistDao.createPlaylist(PlaylistEntity(name = name))
    }

    suspend fun deletePlaylist(playlistId: Long) = withContext(Dispatchers.IO) {
        playlistDao.clearPlaylistTracks(playlistId)
        playlistDao.deletePlaylist(playlistId)
    }

    suspend fun addTrackToPlaylist(playlistId: Long, trackPath: String) = withContext(Dispatchers.IO) {
        playlistDao.addTrackToPlaylist(PlaylistTrackCrossRef(playlistId, trackPath))
    }

    suspend fun removeTrackFromPlaylist(playlistId: Long, trackPath: String) = withContext(Dispatchers.IO) {
        playlistDao.removeTrackFromPlaylist(playlistId, trackPath)
    }

    // Clear all scanned tracks
    suspend fun clearAllTracks() = withContext(Dispatchers.IO) {
        trackDao.clearAllTracks()
    }

    // Inject demo music catalog
    suspend fun injectDemoTracks() = withContext(Dispatchers.IO) {
        val demoEntities = getDemoTracks().map { it.toEntity() }
        trackDao.insertTracks(demoEntities)
    }

    fun getDemoTracks(): List<TrackInfo> {
        return listOf(
            TrackInfo(
                title = "Quantum Resonance",
                artist = "Chrissy Godwin",
                album = "HoloCore Sessions Vol. I",
                sampleRate = "11.2 MHz",
                bitDepth = "1-bit",
                format = "DSD256",
                durationSec = 284,
                filePath = "demo://quantum_resonance.dsf",
                isHiRes = true,
                codec = "Direct Stream Digital",
                bitrate = "5644 kbps",
                genre = "Ambient Electronic",
                folder = "Hi-Res Masters",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 3, // 3 days ago
                playCount = 12
            ),
            TrackInfo(
                title = "Acoustic Reflection",
                artist = "AuraWave Lab",
                album = "Absolute Zero Noise Floor",
                sampleRate = "384 kHz",
                bitDepth = "32-bit",
                format = "FLAC DXD",
                durationSec = 345,
                filePath = "demo://acoustic_reflection.flac",
                isHiRes = true,
                codec = "Free Lossless Audio Codec",
                bitrate = "3072 kbps",
                genre = "Acoustic Jazz",
                folder = "Hi-Res Masters",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 2, // 2 days ago
                playCount = 8
            ),
            TrackInfo(
                title = "Holographic Space",
                artist = "HoloCore Quartet",
                album = "Live at Munich High-End",
                sampleRate = "768 kHz",
                bitDepth = "32-bit",
                format = "WAV PCM",
                durationSec = 192,
                filePath = "demo://holographic_space.wav",
                isHiRes = true,
                codec = "Linear PCM",
                bitrate = "9216 kbps",
                genre = "Classical Symphony",
                folder = "High-End Live",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 12, // 12 hours ago
                playCount = 15
            ),
            TrackInfo(
                title = "Midnight Ambient",
                artist = "Chrissy Godwin",
                album = "HoloCore Sessions Vol. I",
                sampleRate = "96 kHz",
                bitDepth = "24-bit",
                format = "ALAC",
                durationSec = 412,
                filePath = "demo://midnight_ambient.m4a",
                isHiRes = true,
                codec = "Apple Lossless Audio Codec",
                bitrate = "1840 kbps",
                genre = "Chillout Ambient",
                folder = "Hi-Res Masters",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 5,
                playCount = 5
            ),
            TrackInfo(
                title = "Triode Harmonics",
                artist = "Vacuum Tube Trio",
                album = "Warm Harmonics Live",
                sampleRate = "192 kHz",
                bitDepth = "24-bit",
                format = "AIFF",
                durationSec = 224,
                filePath = "demo://triode_harmonics.aif",
                isHiRes = true,
                codec = "Audio Interchange File Format",
                bitrate = "4608 kbps",
                genre = "Analog Fusion",
                folder = "Tube Sessions",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 2,
                playCount = 0
            ),
            TrackInfo(
                title = "Bit-Perfect Symphony",
                artist = "Munich Philharmonic",
                album = "Pure Acoustic Recordings",
                sampleRate = "192 kHz",
                bitDepth = "24-bit",
                format = "FLAC Studio",
                durationSec = 512,
                filePath = "demo://bit_perfect_symphony.flac",
                isHiRes = true,
                codec = "Free Lossless Audio Codec",
                bitrate = "2844 kbps",
                genre = "Orchestral",
                folder = "High-End Live",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 10,
                playCount = 20
            ),
            TrackInfo(
                title = "Analog Emulation",
                artist = "Waveform Synthesist",
                album = "Synthetic Realities",
                sampleRate = "22.4 MHz",
                bitDepth = "1-bit",
                format = "DSD512",
                durationSec = 295,
                filePath = "demo://analog_emulation.dsf",
                isHiRes = true,
                codec = "Direct Stream Digital",
                bitrate = "11288 kbps",
                genre = "Electronic Synth",
                folder = "Synthetic",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 7,
                playCount = 1
            ),
            TrackInfo(
                title = "Silicon Valleys",
                artist = "DSP Experimentalist",
                album = "Nyquist Frequencies",
                sampleRate = "48 kHz",
                bitDepth = "16-bit",
                format = "Opus",
                durationSec = 178,
                filePath = "demo://silicon_valleys.opus",
                isHiRes = false,
                codec = "Opus Interactive Audio Codec",
                bitrate = "128 kbps",
                genre = "IDM",
                folder = "Digital Tests",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 1,
                playCount = 4
            ),
            TrackInfo(
                title = "Golden Ear Master",
                artist = "Reference Mastering Guild",
                album = "The Ultimate Audio Test",
                sampleRate = "352.8 kHz",
                bitDepth = "24-bit",
                format = "MQA Studio",
                durationSec = 320,
                filePath = "demo://golden_ear_master.flac",
                isHiRes = true,
                codec = "Master Quality Authenticated",
                bitrate = "3210 kbps",
                genre = "Audiophile Reference",
                folder = "Test Signals",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 12,
                playCount = 33
            ),
            TrackInfo(
                title = "Noiseless Horizon",
                artist = "Silent Soundscapes",
                album = "Absolute Silence Suite",
                sampleRate = "96 kHz",
                bitDepth = "24-bit",
                format = "FLAC",
                durationSec = 480,
                filePath = "demo://noiseless_horizon.flac",
                isHiRes = true,
                codec = "Free Lossless Audio Codec",
                bitrate = "1120 kbps",
                genre = "Minimalist Ambient",
                folder = "Test Signals",
                dateAdded = System.currentTimeMillis() - 1000 * 60 * 60 * 24 * 14,
                playCount = 0
            )
        )
    }
}
