package com.chrissygodwin.aurawavex.service

import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.audio.AudioProcessor.UnhandledAudioFormatException
import java.nio.ByteBuffer
import java.nio.ByteOrder

class HoloCoreAudioProcessor : AudioProcessor {
    private var pendingInputFormat = AudioFormat.NOT_SET
    private var pendingOutputFormat = AudioFormat.NOT_SET
    private var inputFormat = AudioFormat.NOT_SET
    private var outputFormat = AudioFormat.NOT_SET
    
    private var buffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded = false
    
    // Core Engine state
    private var holoCoreEnabled = false
    private var activeProfileIndex = 0
    private var intensity = 0.5f

    // 16 Independent Module Settings (Thread-safe volatile variables for fast real-time updates)
    @Volatile private var wideSoundstageEnabled = true
    @Volatile private var wideSoundstageStrength = 0.5f

    @Volatile private var instrumentPlacementEnabled = true
    @Volatile private var instrumentPlacementStrength = 0.5f

    @Volatile private var separationEnabled = true
    @Volatile private var separationStrength = 0.5f

    @Volatile private var stereoWidthEnabled = true
    @Volatile private var stereoWidthStrength = 0.5f

    @Volatile private var centerImagingEnabled = true
    @Volatile private var centerImagingStrength = 0.5f

    @Volatile private var dynamicEnabled = true
    @Volatile private var dynamicStrength = 0.5f

    @Volatile private var airEnabled = true
    @Volatile private var airStrength = 0.5f

    @Volatile private var detailEnabled = true
    @Volatile private var detailStrength = 0.5f

    @Volatile private var bassEnabled = true
    @Volatile private var bassStrength = 0.5f

    @Volatile private var vocalEnabled = true
    @Volatile private var vocalStrength = 0.5f

    @Volatile private var trebleEnabled = true
    @Volatile private var trebleStrength = 0.5f

    @Volatile private var crossfeedEnabled = true
    @Volatile private var crossfeedStrength = 0.5f

    @Volatile private var midSideEnabled = true
    @Volatile private var midSideStrength = 0.5f

    @Volatile private var phaseEnabled = true
    @Volatile private var phaseStrength = 0.5f

    @Volatile private var limiterEnabled = true
    @Volatile private var limiterStrength = 0.5f

    @Volatile private var antiClippingEnabled = true
    @Volatile private var antiClippingStrength = 0.5f

    @Volatile private var frontDepthEnabled = true
    @Volatile private var frontDepthStrength = 0.5f

    @Volatile private var rearAmbienceEnabled = true
    @Volatile private var rearAmbienceStrength = 0.5f

    // DSP State History Buffers (to prevent transient noise & enable delay/reflection effects)
    // Long buffer for Wide Soundstage (up to 40ms at 44.1kHz is approx 1764 samples)
    private val reflectionBufferL = FloatArray(2048)
    private val reflectionBufferR = FloatArray(2048)
    private var reflectionIndex = 0

    // Binaural delay buffer for Instrument Placement (up to 128 samples)
    private val binauralBufferL = FloatArray(128)
    private val binauralBufferR = FloatArray(128)
    private var binauralIndex = 0

    // Front depth & Rear Ambience buffers
    private val frontDepthBufferL = FloatArray(256)
    private val frontDepthBufferR = FloatArray(256)
    private var frontDepthIndex = 0

    private val rearAmbienceBufferL = FloatArray(512)
    private val rearAmbienceBufferR = FloatArray(512)
    private var rearAmbienceIndex = 0

    private var lastInputL = 0f
    private var lastInputR = 0f
    private var lastOutputL = 0f
    private var lastOutputR = 0f

    // LPF state for Bass & Crossfeed
    private var lpfL = 0f
    private var lpfR = 0f
    private var crossfeedLpfL = 0f
    private var crossfeedLpfR = 0f

    // HPF state for Air
    private var airHpfL = 0f
    private var airHpfR = 0f

    // Shelving filters for Treble
    private var trebleLpfL = 0f
    private var trebleLpfR = 0f

    // Phase alignment memory
    private var lastPhaseL = 0f
    private var lastPhaseR = 0f

    // Vocal focus bandpass state
    private var vocalBpL = 0f
    private var vocalBpR = 0f

    fun updateDspSettings(enabled: Boolean, profileIndex: Int, dspIntensity: Float) {
        this.holoCoreEnabled = enabled
        this.activeProfileIndex = profileIndex
        this.intensity = dspIntensity
        com.chrissygodwin.aurawavex.dsp.DspCore.masterEnabled = enabled
        com.chrissygodwin.aurawavex.dsp.DspCore.masterIntensity = dspIntensity
    }

    fun updateModule(id: String, enabled: Boolean, strength: Float) {
        val clampedStrength = strength.coerceIn(0f, 1f)
        com.chrissygodwin.aurawavex.dsp.ParameterManager.updateModuleParameter(id, enabled, clampedStrength)
        when (id) {
            "wide_soundstage" -> { wideSoundstageEnabled = enabled; wideSoundstageStrength = clampedStrength }
            "instrument_placement" -> { instrumentPlacementEnabled = enabled; instrumentPlacementStrength = clampedStrength }
            "separation" -> { separationEnabled = enabled; separationStrength = clampedStrength }
            "stereo_width" -> { stereoWidthEnabled = enabled; stereoWidthStrength = clampedStrength }
            "center_imaging" -> { centerImagingEnabled = enabled; centerImagingStrength = clampedStrength }
            "dynamic" -> { dynamicEnabled = enabled; dynamicStrength = clampedStrength }
            "air" -> { airEnabled = enabled; airStrength = clampedStrength }
            "detail" -> { detailEnabled = enabled; detailStrength = clampedStrength }
            "bass" -> { bassEnabled = enabled; bassStrength = clampedStrength }
            "vocal" -> { vocalEnabled = enabled; vocalStrength = clampedStrength }
            "treble" -> { trebleEnabled = enabled; trebleStrength = clampedStrength }
            "crossfeed" -> { crossfeedEnabled = enabled; crossfeedStrength = clampedStrength }
            "mid_side" -> { midSideEnabled = enabled; midSideStrength = clampedStrength }
            "phase" -> { phaseEnabled = enabled; phaseStrength = clampedStrength }
            "limiter" -> { limiterEnabled = enabled; limiterStrength = clampedStrength }
            "anti_clipping" -> { antiClippingEnabled = enabled; antiClippingStrength = clampedStrength }
            "front_depth" -> { frontDepthEnabled = enabled; frontDepthStrength = clampedStrength }
            "rear_ambience" -> { rearAmbienceEnabled = enabled; rearAmbienceStrength = clampedStrength }
        }
    }

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT) {
            throw UnhandledAudioFormatException(inputAudioFormat)
        }
        pendingInputFormat = inputAudioFormat
        pendingOutputFormat = inputAudioFormat
        return pendingOutputFormat
    }

    override fun isActive(): Boolean {
        return pendingInputFormat != AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }

        // Process PCM 16-bit audio if HoloCore is enabled
        if (holoCoreEnabled) {
            val shortBuffer = inputBuffer.asShortBuffer()
            val outShortBuffer = buffer.asShortBuffer()
            val samplesCount = shortBuffer.remaining()
            
            if (pendingInputFormat.channelCount == 2) {
                // Stereo path
                val pairs = samplesCount / 2
                for (p in 0 until pairs) {
                    if (shortBuffer.remaining() >= 2) {
                        val leftSample = shortBuffer.get()
                        val rightSample = shortBuffer.get()
                        val (outL, outR) = applyStereoDsp(leftSample, rightSample)
                        outShortBuffer.put(outL)
                        outShortBuffer.put(outR)
                    }
                }
                if (shortBuffer.hasRemaining()) {
                    outShortBuffer.put(shortBuffer.get())
                }
            } else {
                // Mono path fallback
                for (i in 0 until samplesCount) {
                    if (shortBuffer.hasRemaining()) {
                        val sample = shortBuffer.get()
                        val processed = applyMonoDsp(sample)
                        outShortBuffer.put(processed)
                    }
                }
            }
            
            inputBuffer.position(inputBuffer.limit())
            buffer.limit(remaining)
        } else {
            buffer.put(inputBuffer)
        }

        buffer.flip()
        outputBuffer = buffer
    }

    private fun applyStereoDsp(leftSample: Short, rightSample: Short): Pair<Short, Short> {
        var l = leftSample.toFloat() / 32768f
        var r = rightSample.toFloat() / 32768f

        // Apply profile-specific multipliers or adjustments if applicable
        // This makes sure both presets and individual modular controls integrate cleanly!
        var profileMult = 1.0f
        if (activeProfileIndex > 0) {
            profileMult = intensity
        }

        // =========================================================================
        // STEP 1: HoloCore™ 3D Holographic Sound Simulation ⭐
        // =========================================================================
        
        // 1a. Stereo Width Module (Side-to-mid balance expansion)
        var mid = (l + r) * 0.5f
        var side = (l - r) * 0.5f
        if (stereoWidthEnabled) {
            val widthFactor = 0.4f + stereoWidthStrength * 1.4f * profileMult
            side *= widthFactor
            l = mid + side
            r = mid - side
        }

        // 1b. Wide Soundstage Module (Room reflections simulation)
        if (wideSoundstageEnabled) {
            reflectionBufferL[reflectionIndex] = l
            reflectionBufferR[reflectionIndex] = r
            // reflection delay around 20-35ms (880 to 1540 samples at 44.1kHz)
            val delaySamples = (800 + (wideSoundstageStrength * 700 * profileMult)).toInt().coerceIn(1, 2047)
            val readIndex = (reflectionIndex - delaySamples + 2048) % 2048
            val reflectedL = reflectionBufferL[readIndex]
            val reflectedR = reflectionBufferR[readIndex]

            // Inject low level room reflection with cross-channel feedback
            l += reflectedR * (0.12f * wideSoundstageStrength * profileMult)
            r += reflectedL * (0.12f * wideSoundstageStrength * profileMult)

            reflectionIndex = (reflectionIndex + 1) % 2048
        }

        // 1c. Instrument Placement Module (Binaural micro-delays)
        if (instrumentPlacementEnabled) {
            binauralBufferL[binauralIndex] = l
            binauralBufferR[binauralIndex] = r
            // Binaural/Haas delay of 10 to 30 samples to spatialize instruments
            val delaySamples = (10 + (instrumentPlacementStrength * 20 * profileMult)).toInt().coerceIn(1, 127)
            val readIndex = (binauralIndex - delaySamples + 128) % 128
            val delayedL = binauralBufferL[readIndex]
            val delayedR = binauralBufferR[readIndex]

            // Out of phase channel mixing creates stunning 3D width and precision
            l -= delayedR * (0.15f * instrumentPlacementStrength * profileMult)
            r -= delayedL * (0.15f * instrumentPlacementStrength * profileMult)

            binauralIndex = (binauralIndex + 1) % 128
        }

        // 1d. Front Depth Module (Early reflections from front projection)
        if (frontDepthEnabled) {
            frontDepthBufferL[frontDepthIndex] = l
            frontDepthBufferR[frontDepthIndex] = r
            // Micro-delay of 15 to 45 samples for front-field depth
            val delaySamples = (15 + (frontDepthStrength * 30 * profileMult)).toInt().coerceIn(1, 255)
            val readIndex = (frontDepthIndex - delaySamples + 256) % 256
            
            // Subtle in-phase combination to simulate early front-wall bounces
            l += frontDepthBufferL[readIndex] * (0.10f * frontDepthStrength * profileMult)
            r += frontDepthBufferR[readIndex] * (0.10f * frontDepthStrength * profileMult)
            
            frontDepthIndex = (frontDepthIndex + 1) % 256
        }

        // 1e. Rear Ambience Module (Low-passed diffuse room reflections from the back)
        if (rearAmbienceEnabled) {
            rearAmbienceBufferL[rearAmbienceIndex] = l
            rearAmbienceBufferR[rearAmbienceIndex] = r
            // Delay of 40 to 120 samples to simulate rear sound propagation
            val delaySamples = (40 + (rearAmbienceStrength * 80 * profileMult)).toInt().coerceIn(1, 511)
            val readIndex = (rearAmbienceIndex - delaySamples + 512) % 512
            
            // Out-of-phase crossfed signal to build a diffuse, wrapping ambient cloud
            val ambientL = rearAmbienceBufferL[readIndex]
            val ambientR = rearAmbienceBufferR[readIndex]
            l -= ambientR * (0.08f * rearAmbienceStrength * profileMult)
            r -= ambientL * (0.08f * rearAmbienceStrength * profileMult)
            
            rearAmbienceIndex = (rearAmbienceIndex + 1) % 512
        }

        // 1f. Center Imaging Module (Center field stabilization)
        if (centerImagingEnabled) {
            mid = (l + r) * 0.5f
            side = (l - r) * 0.5f
            // Slightly compress/stabilize mid while preserving side
            val factor = 1f - (0.05f * centerImagingStrength * profileMult)
            l = mid * factor + side
            r = mid * factor - side
        }

        // 1g. Instrument Separation Module (Stereo decoupling)
        if (separationEnabled) {
            mid = (l + r) * 0.5f
            side = (l - r) * 0.5f
            val midRed = 1f - 0.08f * separationStrength
            val sideInc = 1f + 0.18f * separationStrength * profileMult
            l = mid * midRed + side * sideInc
            r = mid * midRed - side * sideInc
        }

        // =========================================================================
        // STEP 2: Professional Equalizer
        // =========================================================================
        val activeEq = com.chrissygodwin.aurawavex.dsp.DspCore.activeEqualizer
        if (activeEq.isEnabled) {
            val (eqL, eqR) = activeEq.processStereo(l, r)
            l = eqL
            r = eqR
        }

        // =========================================================================
        // STEP 3: Additional DSP Modules
        // =========================================================================

        // 3a. Crossfeed Module (Acoustic head-shadow cues)
        if (crossfeedEnabled) {
            // Apply a simple low-pass filter to the crossfed signal
            crossfeedLpfL = 0.15f * l + 0.85f * crossfeedLpfL
            crossfeedLpfR = 0.15f * r + 0.85f * crossfeedLpfR
            val feed = crossfeedStrength * 0.25f * profileMult
            val lNew = l * (1f - feed) + crossfeedLpfR * feed
            val rNew = r * (1f - feed) + crossfeedLpfL * feed
            l = lNew
            r = rNew
        }

        // 3b. Mid/Side Processing Module
        if (midSideEnabled) {
            mid = (l + r) * 0.5f
            side = (l - r) * 0.5f
            val midGain = 0.9f + (1f - midSideStrength) * 0.2f
            val sideGain = 0.9f + midSideStrength * 0.2f * profileMult
            l = mid * midGain + side * sideGain
            r = mid * midGain - side * sideGain
        }

        // 3c. Dynamic Enhancement Module (Transient Punch / Expansion)
        if (dynamicEnabled) {
            val absL = kotlin.math.abs(l)
            val absR = kotlin.math.abs(r)
            val threshold = 0.15f
            val factor = 1.0f + dynamicStrength * 0.15f * profileMult
            if (absL > threshold) l *= factor
            if (absR > threshold) r *= factor
        }

        // 3d. Air Enhancement Module (Ultrasonic high-shelf filter)
        val hpL = l - lastInputL + 0.90f * lastOutputL
        val hpR = r - lastInputR + 0.90f * lastOutputR
        lastInputL = l
        lastInputR = r
        lastOutputL = hpL
        lastOutputR = hpR

        if (airEnabled) {
            l += hpL * (0.32f * airStrength * profileMult)
            r += hpR * (0.32f * airStrength * profileMult)
        }

        // 3e. Detail Enhancement Module (High-frequency transient extraction)
        if (detailEnabled) {
            val diffL = l - lastInputL
            val diffR = r - lastInputR
            l += diffL * (0.22f * detailStrength * profileMult)
            r += diffR * (0.22f * detailStrength * profileMult)
        }

        // 3f. Controlled Bass Module (Sub-bass boost & contouring)
        lpfL = 0.12f * l + 0.88f * lpfL
        lpfR = 0.12f * r + 0.88f * lpfR
        if (bassEnabled) {
            val bassGain = bassStrength * 0.38f * profileMult
            l += lpfL * bassGain
            r += lpfR * bassGain
        }

        // 3g. Vocal Focus Module (Midrange preservation/boost)
        if (vocalEnabled) {
            mid = (l + r) * 0.5f
            vocalBpL = 0.18f * mid + 0.82f * vocalBpL
            val vocalBand = vocalBpL * 0.22f * vocalStrength * profileMult
            l += vocalBand
            r += vocalBand
        }

        // 3h. Treble Refinement Module (Polishes high spikes smoothly)
        if (trebleEnabled) {
            trebleLpfL = 0.25f * l + 0.75f * trebleLpfL
            trebleLpfR = 0.25f * r + 0.75f * trebleLpfR
            val blend = trebleStrength * 0.4f * profileMult
            l = l * (1f - blend) + trebleLpfL * blend
            r = r * (1f - blend) + trebleLpfR * blend
        }

        // 3i. Phase Optimization Module (Transient alignment)
        if (phaseEnabled) {
            val tempL = l
            val tempR = r
            l = l * 0.94f + lastPhaseL * 0.06f
            r = r * 0.94f + lastPhaseR * 0.06f
            lastPhaseL = tempL
            lastPhaseR = tempR
        }

        // 3j. Intelligent Limiter Module (Acoustic peak ceiling limiter)
        if (limiterEnabled) {
            val maxVal = kotlin.math.max(kotlin.math.abs(l), kotlin.math.abs(r))
            val limitThreshold = 0.90f
            if (maxVal > limitThreshold) {
                val reductionFactor = limitThreshold / maxVal
                l *= (reductionFactor * limiterStrength + (1f - limiterStrength))
                r *= (reductionFactor * limiterStrength + (1f - limiterStrength))
            }
        }

        // 3k. Anti-Clipping Protection Module (Soft saturation)
        if (antiClippingEnabled) {
            l = kotlin.math.tanh(l * (1f + 0.12f * antiClippingStrength)).toFloat() / (1f + 0.12f * antiClippingStrength)
            r = kotlin.math.tanh(r * (1f + 0.12f * antiClippingStrength)).toFloat() / (1f + 0.12f * antiClippingStrength)
        } else {
            l = l.coerceIn(-1.0f, 1.0f)
            r = r.coerceIn(-1.0f, 1.0f)
        }

        // Convert back to PCM 16-bit Short value safely
        val outL = (l * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        val outR = (r * 32767f).toInt().coerceIn(-32768, 32767).toShort()
        return Pair(outL, outR)
    }

    private fun applyMonoDsp(sample: Short): Short {
        val (outL, _) = applyStereoDsp(sample, sample)
        return outL
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val output = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return output
    }

    override fun isEnded(): Boolean {
        return inputEnded && outputBuffer == AudioProcessor.EMPTY_BUFFER
    }

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        inputFormat = pendingInputFormat
        outputFormat = pendingOutputFormat
        
        // Reset buffers & states to avoid click/pop artifacts on track changes or seek
        reflectionBufferL.fill(0f)
        reflectionBufferR.fill(0f)
        reflectionIndex = 0

        binauralBufferL.fill(0f)
        binauralBufferR.fill(0f)
        binauralIndex = 0

        frontDepthBufferL.fill(0f)
        frontDepthBufferR.fill(0f)
        frontDepthIndex = 0

        rearAmbienceBufferL.fill(0f)
        rearAmbienceBufferR.fill(0f)
        rearAmbienceIndex = 0
        
        lastInputL = 0f
        lastInputR = 0f
        lastOutputL = 0f
        lastOutputR = 0f
        
        lpfL = 0f
        lpfR = 0f
        crossfeedLpfL = 0f
        crossfeedLpfR = 0f

        airHpfL = 0f
        airHpfR = 0f

        trebleLpfL = 0f
        trebleLpfR = 0f
        
        lastPhaseL = 0f
        lastPhaseR = 0f

        vocalBpL = 0f
        vocalBpR = 0f
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        pendingInputFormat = AudioFormat.NOT_SET
        pendingOutputFormat = AudioFormat.NOT_SET
        inputFormat = AudioFormat.NOT_SET
        outputFormat = AudioFormat.NOT_SET
    }
}
