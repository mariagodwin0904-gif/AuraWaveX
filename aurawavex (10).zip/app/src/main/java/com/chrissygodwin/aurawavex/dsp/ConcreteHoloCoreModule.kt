package com.chrissygodwin.aurawavex.dsp

/**
 * Concrete implementation of the high-performance IHoloCoreModule interface.
 * Used by DspCore to hold thread-safe modular parameters.
 */
class ConcreteHoloCoreModule(
    override val id: String,
    override val name: String,
    override val description: String,
    override val category: ModuleCategory,
    override var isEnabled: Boolean = true,
    override var strength: Float = 0.5f,
    private val defaultEnabled: Boolean = true,
    private val defaultStrength: Float = 0.5f
) : IHoloCoreModule {

    override fun reset() {
        isEnabled = defaultEnabled
        strength = defaultStrength
    }
}
