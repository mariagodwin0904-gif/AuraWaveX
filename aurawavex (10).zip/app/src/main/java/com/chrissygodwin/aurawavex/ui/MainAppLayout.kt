package com.chrissygodwin.aurawavex.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.chrissygodwin.aurawavex.navigation.Screen
import com.chrissygodwin.aurawavex.ui.components.FullScreenPlayer
import com.chrissygodwin.aurawavex.ui.components.MiniPlayer
import com.chrissygodwin.aurawavex.ui.screens.AnalyzerScreen
import com.chrissygodwin.aurawavex.ui.screens.EqScreen
import com.chrissygodwin.aurawavex.ui.screens.HoloCoreScreen
import com.chrissygodwin.aurawavex.ui.screens.HomeScreen
import com.chrissygodwin.aurawavex.ui.screens.MusicScreen
import com.chrissygodwin.aurawavex.ui.screens.SettingsScreen
import com.chrissygodwin.aurawavex.ui.screens.SplashScreen
import com.chrissygodwin.aurawavex.ui.theme.AmoledBlack
import com.chrissygodwin.aurawavex.ui.theme.NeonLimeGreen
import com.chrissygodwin.aurawavex.ui.theme.RoyalBlue
import com.chrissygodwin.aurawavex.ui.theme.TextPrimary
import com.chrissygodwin.aurawavex.ui.theme.TextSecondary
import com.chrissygodwin.aurawavex.viewmodel.AudioViewModel

@Composable
fun MainAppLayout() {
    val navController = rememberNavController()
    val viewModel: AudioViewModel = viewModel()

    var showSplash by remember { mutableStateOf(true) }

    AnimatedVisibility(
        visible = showSplash,
        enter = fadeIn(animationSpec = tween(400)),
        exit = fadeOut(animationSpec = tween(400))
    ) {
        SplashScreen(onSplashComplete = { showSplash = false })
    }

    AnimatedVisibility(
        visible = !showSplash,
        enter = fadeIn(animationSpec = tween(400)),
        exit = fadeOut(animationSpec = tween(400))
    ) {
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route
        val uiState by viewModel.uiState.collectAsState()

        Box(modifier = Modifier.fillMaxSize()) {
            Scaffold(
                bottomBar = {
                    Column(
                        modifier = Modifier
                            .background(AmoledBlack)
                            .navigationBarsPadding()
                    ) {
                        // Persistent Mini Player above navigation bar
                        MiniPlayer(
                            viewModel = viewModel,
                            onMiniPlayerClick = { viewModel.setFullScreenPlayerVisible(true) }
                        )

                        // Small Divider
                        HorizontalDivider(color = Color(0xFF1C1C1E), thickness = 0.5.dp)

                        // Centered, Elegant Credit Footer
                        Text(
                            text = "Developed by Chrissy Godwin",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp, bottom = 4.dp)
                                .testTag("chrissy_godwin_footer")
                        )

                        // Bottom Navigation tabs
                        NavigationBar(
                            containerColor = AmoledBlack,
                            tonalElevation = 0.dp,
                            modifier = Modifier.testTag("bottom_nav_bar")
                        ) {
                            Screen.mainTabs.forEach { tab ->
                                val isSelected = currentRoute == tab.route
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = {
                                        if (currentRoute != tab.route) {
                                            navController.navigate(tab.route) {
                                                popUpTo(Screen.Home.route) {
                                                    saveState = true
                                                }
                                                launchSingleTop = true
                                                restoreState = true
                                            }
                                        }
                                    },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
                                            contentDescription = tab.title,
                                            modifier = Modifier.testTag("nav_icon_${tab.route}")
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = tab.title,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 1
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = NeonLimeGreen,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary,
                                        indicatorColor = NeonLimeGreen
                                    )
                                )
                            }
                        }
                    }
                },
                containerColor = AmoledBlack,
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                NavHost(
                    navController = navController,
                    startDestination = Screen.Home.route,
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                        .background(AmoledBlack)
                ) {
                    composable(Screen.Home.route) {
                        HomeScreen(viewModel = viewModel)
                    }
                    composable(Screen.Music.route) {
                        MusicScreen(viewModel = viewModel)
                    }
                    composable(Screen.HoloCore.route) {
                        HoloCoreScreen(viewModel = viewModel)
                    }
                    composable(Screen.Eq.route) {
                        EqScreen(viewModel = viewModel)
                    }
                    composable(Screen.Analyzer.route) {
                        AnalyzerScreen(viewModel = viewModel)
                    }
                    composable(Screen.Settings.route) {
                        SettingsScreen()
                    }
                }
            }

            // Beautiful Slide-up Full Screen Player Overlay
            AnimatedVisibility(
                visible = uiState.isFullScreenPlayerVisible,
                enter = slideInVertically(
                    initialOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 400f)
                ),
                exit = slideOutVertically(
                    targetOffsetY = { it },
                    animationSpec = spring(dampingRatio = 0.85f, stiffness = 400f)
                )
            ) {
                FullScreenPlayer(
                    viewModel = viewModel,
                    onDismiss = { viewModel.setFullScreenPlayerVisible(false) }
                )
            }
        }
    }
}
