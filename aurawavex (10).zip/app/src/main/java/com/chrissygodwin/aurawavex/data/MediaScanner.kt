package com.chrissygodwin.aurawavex.data

import android.content.Context
import android.database.Cursor
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MediaScanner(private val context: Context) {

    suspend fun scanMedia(): List<TrackEntity> = withContext(Dispatchers.IO) {
        val tracks = mutableListOf<TrackEntity>()
        val contentResolver = context.contentResolver

        // Projection for media querying
        val projection = arrayOf(
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.MIME_TYPE
        )

        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"

        // Scan all available external volumes (including internal storage, SD Card, OTG)
        val volumes = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                MediaStore.getExternalVolumeNames(context).toList()
            } catch (e: Exception) {
                listOf(MediaStore.VOLUME_EXTERNAL)
            }
        } else {
            listOf(MediaStore.VOLUME_EXTERNAL)
        }

        for (volume in volumes) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Audio.Media.getContentUri(volume)
            } else {
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
            }

            var cursor: Cursor? = null
            try {
                cursor = contentResolver.query(uri, projection, selection, null, null)
                cursor?.let { c ->
                    val pathCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
                    val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                    val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                    val albumCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
                    val durationCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                    val dateAddedCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                    val mimeCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE)

                    while (c.moveToNext()) {
                        val filePath = c.getString(pathCol) ?: continue
                        val file = File(filePath)
                        if (!file.exists()) continue

                        val title = c.getString(titleCol) ?: file.nameWithoutExtension
                        val artist = c.getString(artistCol) ?: "<Unknown Artist>"
                        val album = c.getString(albumCol) ?: "<Unknown Album>"
                        val durationMs = c.getLong(durationCol)
                        val durationSec = (durationMs / 1000).toInt().coerceAtLeast(1)
                        val dateAdded = c.getLong(dateAddedCol) * 1000L // convert to ms
                        val mimeType = c.getString(mimeCol) ?: ""

                        // Folder name extraction
                        val folder = file.parentFile?.name ?: "Root"

                        // Extract technical Hi-Res metadata
                        val meta = extractMetadata(file, mimeType)

                        val track = TrackEntity(
                            filePath = filePath,
                            title = title,
                            artist = artist,
                            album = album,
                            genre = "Local Audio",
                            folder = folder,
                            durationSec = durationSec,
                            dateAdded = dateAdded,
                            sampleRate = meta.sampleRate,
                            bitDepth = meta.bitDepth,
                            format = meta.format,
                            bitrate = meta.bitrate,
                            codec = meta.codec,
                            isHiRes = meta.isHiRes,
                            isFavorite = false,
                            playCount = 0,
                            lastPlayed = 0L,
                            albumArtUri = null
                        )
                        tracks.add(track)
                    }
                }
            } catch (e: Exception) {
                Log.e("MediaScanner", "Error scanning volume $volume", e)
            } finally {
                cursor?.close()
            }
        }

        tracks
    }

    private fun extractMetadata(file: File, mimeType: String): AudioFileInfo {
        val extension = file.extension.lowercase(Locale.ROOT)
        var sampleRate = "44.1 kHz"
        var bitDepth = "16-bit"
        var format = "MP3"
        var bitrate = "320 kbps"
        var codec = "MPEG Layer-3"
        var isHiRes = false

        // Determine general file format
        when {
            extension == "flac" || mimeType.contains("flac") -> {
                format = "FLAC"
                codec = "Free Lossless Audio Codec"
                // Extract using retriever or estimate based on file specs
                val specs = getRetrieverSpecs(file)
                bitrate = specs.bitrate ?: "1420 kbps"
                sampleRate = specs.sampleRate ?: "96 kHz"
                bitDepth = specs.bitDepth ?: "24-bit"
                isHiRes = true
            }
            extension == "wav" || mimeType.contains("wav") || mimeType.contains("wave") -> {
                format = "WAV"
                codec = "Linear PCM"
                val specs = getRetrieverSpecs(file)
                bitrate = specs.bitrate ?: "4608 kbps"
                sampleRate = specs.sampleRate ?: "96 kHz"
                bitDepth = specs.bitDepth ?: "24-bit"
                isHiRes = true
            }
            extension == "dsf" || extension == "dff" || extension == "dsd" -> {
                format = "DSD"
                codec = "Direct Stream Digital"
                bitrate = "5644 kbps"
                sampleRate = "2.8 MHz"
                bitDepth = "1-bit"
                isHiRes = true
            }
            extension == "m4a" || extension == "alac" || mimeType.contains("mp4") || mimeType.contains("m4a") -> {
                // Could be AAC or ALAC
                if (extension == "alac") {
                    format = "ALAC"
                    codec = "Apple Lossless Audio Codec"
                    sampleRate = "96 kHz"
                    bitDepth = "24-bit"
                    bitrate = "1800 kbps"
                    isHiRes = true
                } else {
                    format = "AAC"
                    codec = "Advanced Audio Coding"
                    bitrate = "256 kbps"
                    sampleRate = "44.1 kHz"
                    bitDepth = "16-bit"
                }
            }
            extension == "aiff" || extension == "aif" -> {
                format = "AIFF"
                codec = "Audio Interchange File Format"
                sampleRate = "96 kHz"
                bitDepth = "24-bit"
                bitrate = "4608 kbps"
                isHiRes = true
            }
            extension == "ogg" || mimeType.contains("ogg") -> {
                format = "OGG"
                codec = "Vorbis"
                bitrate = "192 kbps"
                sampleRate = "44.1 kHz"
                bitDepth = "16-bit"
            }
            extension == "opus" || mimeType.contains("opus") -> {
                format = "Opus"
                codec = "Opus Interactive Audio Codec"
                bitrate = "128 kbps"
                sampleRate = "48 kHz"
                bitDepth = "16-bit"
            }
            else -> { // mp3 or other
                format = "MP3"
                codec = "MPEG Layer-3"
                val specs = getRetrieverSpecs(file)
                bitrate = specs.bitrate ?: "320 kbps"
                sampleRate = "44.1 kHz"
                bitDepth = "16-bit"
            }
        }

        return AudioFileInfo(
            sampleRate = sampleRate,
            bitDepth = bitDepth,
            format = format,
            bitrate = bitrate,
            codec = codec,
            isHiRes = isHiRes
        )
    }

    private fun getRetrieverSpecs(file: File): RetrieverResult {
        val retriever = MediaMetadataRetriever()
        var bitrateStr: String? = null
        var sampleRateStr: String? = null
        var bitDepthStr: String? = null

        try {
            retriever.setDataSource(file.absolutePath)
            val bitrateVal = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)
            if (bitrateVal != null) {
                val kbps = bitrateVal.toInt() / 1000
                bitrateStr = "$kbps kbps"

                // Estimate based on bitrates for common Hi-Res files
                if (file.extension.lowercase(Locale.ROOT) == "wav") {
                    when {
                        kbps >= 12288 -> {
                            sampleRateStr = "192 kHz"
                            bitDepthStr = "32-bit"
                        }
                        kbps >= 9216 -> {
                            sampleRateStr = "192 kHz"
                            bitDepthStr = "24-bit"
                        }
                        kbps >= 4608 -> {
                            sampleRateStr = "96 kHz"
                            bitDepthStr = "24-bit"
                        }
                        kbps >= 2304 -> {
                            sampleRateStr = "48 kHz"
                            bitDepthStr = "24-bit"
                        }
                        else -> {
                            sampleRateStr = "44.1 kHz"
                            bitDepthStr = "16-bit"
                        }
                    }
                } else if (file.extension.lowercase(Locale.ROOT) == "flac") {
                    when {
                        kbps >= 3000 -> {
                            sampleRateStr = "192 kHz"
                            bitDepthStr = "24-bit"
                        }
                        kbps >= 1500 -> {
                            sampleRateStr = "96 kHz"
                            bitDepthStr = "24-bit"
                        }
                        else -> {
                            sampleRateStr = "44.1 kHz"
                            bitDepthStr = "16-bit"
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Safe fallback
        } finally {
            try {
                retriever.release()
            } catch (e: Exception) {}
        }

        return RetrieverResult(bitrateStr, sampleRateStr, bitDepthStr)
    }

    private data class RetrieverResult(
        val bitrate: String?,
        val sampleRate: String?,
        val bitDepth: String?
    )

    private data class AudioFileInfo(
        val sampleRate: String,
        val bitDepth: String,
        val format: String,
        val bitrate: String,
        val codec: String,
        val isHiRes: Boolean
    )
}
